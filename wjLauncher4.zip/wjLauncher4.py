import pygame
import subprocess
import os
import datetime
import win32com.client

pygame.init()
screen = pygame.display.set_mode((1280, 700), pygame.RESIZABLE)
scroll_enabled = False

# ---------------- STATE ----------------
begin_scroll_x = 0
dotcom_scroll_x = 0
wj_scroll_x = 0
art_scroll_x = 0
WIDTH, HEIGHT = screen.get_size()

begin_hover = False
dotcom_hover = False
wj_hover = False
art_hover = False
# --- marquee positions (top three + bottom begin) ---
dotcom_y = 40
wj_y = 120
art_y = 200

# ---------------- WINDOW ----------------
screen = pygame.display.set_mode((1280, 700), pygame.RESIZABLE)
WIDTH, HEIGHT = screen.get_size()
pygame.display.set_caption("Multi Launcher")

background = pygame.image.load(
    "C:/Users/spenc/OneDrive/Desktop/Numbers/wjLauncher/background2.png"
).convert()
background = pygame.transform.smoothscale(background, (1280, 700))

# ---------------- FONTS ----------------
FONT = pygame.font.SysFont("arial", 26)
ITEM_FONT = pygame.font.SysFont("arial", 22)

# ---------------- BEGIN MENU ----------------
BEGIN_MENU = [
    ("Windows Explorer", "explorer D:\\Pictures\\"),
    ("Microsoft Paint", "mspaint"),
    ("Adobe Photoshop CS2", "C:/Program Files (x86)/Adobe/Adobe Photoshop CS2/Photoshop.exe"),
    ("Paint Dot Net", "C:/Program Files/Paint,NET/paintdotnet.exe"),
]

# ---------------- MENUS ----------------
MENUS = [
    ("Dot Com", [
        ("Name A File", "D:/PortableAPPLICATIONS/wjFileName/wjFileName.exe"),
        ("Block Art", "D:/PortableAPPLICATIONS/wjBlockArt/wjBlockArt.exe"),
        ("Special Art", "D:/PortableAPPLICATIONS/wjSpecial25/wjSpecial25.exe"),
        ("Photo's Effects", "D:/PortableAPPLICATIONS/wjPhotos/wjPhotos.exe"),
        ("Photo's Folder", "explorer D:\\PortableAPPLICATIONS\\wjPhotos\\art"),
        ("Word Art and Shuffler", "D:/PortableAPPLICATIONS/wjShufflerAndWordArt/wjShufflerAndWordArt.exe"),
        ("20-30 Animation", "D:/PortableAPPLICATIONS/WritersJumbler-XandYanimation-20-30/WritersJumbler-XandYanimation-20-30.exe"),
        ("20-50 Art", "D:/PortableAPPLICATIONS/WritersJumblerArt-20-50/WritersJumblerArt-20-50.exe"),
    ]),
    ("Writer's Jumbler", [
        ("tkWJ1", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ1.exe"),
        ("tkWJ2", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ2.exe"),
        ("tkWJ3", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ3.exe"),
        ("tkWJ4", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ4.exe"),
        ("tkWJ5", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ5.exe"),
    ]),
    ("Jumbler Art", [
        ("25 Art Animation", "C:/Users/spenc/Documents/WritersJumblerPythonArt/dist/WritersJumbler_25_Grid.exe"),
        ("30 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani.exe"),
        ("50 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani.exe"),
        ("30 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani3_ColorCycleMCP.exe"),
        ("50 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani3_ColorCycleMCP.exe"),
        ("30 Art 4 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani4.exe"),
        ("50 Art 4 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani4.exe"),
        ("30 Art 5 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani5.exe"),
        ("50 Art 5 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani5.exe"),
        ("30 Art 6 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani6.exe"),
        ("50 Art 6 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani6.exe"),
        ("150 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView.exe"),
        ("150 Art 2 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView2.exe"),
        ("150 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView3.exe"),
        ("200 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_200_Art_Ani.exe"),
    ]),
]

# ---------------- LAUNCH ----------------
def launch_app(path):
    if os.path.isdir(path):
        subprocess.Popen(["explorer", path])
        return

    if path.lower().endswith(".lnk"):
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(path)
        path = shortcut.TargetPath

    subprocess.Popen(path, shell=True)

# ---------------- TASKBAR ----------------
TASKBAR_HEIGHT = 50
WINDOWS_TASKBAR_OFFSET = 40
begin_y = HEIGHT - TASKBAR_HEIGHT - WINDOWS_TASKBAR_OFFSET + 10
def draw_marquee(surface, items, scroll_x, hover_flag_name, y, item_width=200, gap=10):
    global begin_hover, dotcom_hover, wj_hover, art_hover

    x_start = 10
    cycle_width = len(items) * (item_width + gap)
    scroll_x = scroll_x % cycle_width

    # reset hover
    if hover_flag_name == "begin":
        begin_hover = False
    elif hover_flag_name == "dotcom":
        dotcom_hover = False
    elif hover_flag_name == "wj":
        wj_hover = False
    elif hover_flag_name == "art":
        art_hover = False

    # detect hover
    for copy in range(3):
        x = x_start - scroll_x + (copy * cycle_width)
        for name, path in items:
            item_rect = pygame.Rect(x, y, item_width, 30)
            if item_rect.collidepoint(pygame.mouse.get_pos()):
                if hover_flag_name == "begin":
                    begin_hover = True
                elif hover_flag_name == "dotcom":
                    dotcom_hover = True
                elif hover_flag_name == "wj":
                    wj_hover = True
                elif hover_flag_name == "art":
                    art_hover = True
            x += item_width + gap

    # draw
    for copy in range(3):
        x = x_start - scroll_x + (copy * cycle_width)
        for name, path in items:
            item_rect = pygame.Rect(x, y, item_width, 30)
            hovered = item_rect.collidepoint(pygame.mouse.get_pos())
            pygame.draw.rect(surface, (60, 60, 60) if hovered else (40, 40, 40), item_rect)
            surface.blit(ITEM_FONT.render(name, True, (200, 200, 255)),
                         (item_rect.x + 8, item_rect.y + 5))
            x += item_width + gap

    return scroll_x

def draw_taskbar_datetime(surface):
    y = HEIGHT - TASKBAR_HEIGHT - WINDOWS_TASKBAR_OFFSET + TASKBAR_HEIGHT
    now = datetime.datetime.now()
    date_text = now.strftime("%b %d, %Y")
    time_text = now.strftime("%I:%M %p")

    date_label = FONT.render(date_text, True, (0, 0, 0))
    time_label = FONT.render(time_text, True, (0, 0, 0))

    date_x = (WIDTH // 2) - (date_label.get_width() // 2)
    time_x = WIDTH - time_label.get_width() - 20

    surface.blit(date_label, (date_x, y))
    surface.blit(time_label, (time_x, y))

# ---------------- MAIN LOOP ----------------
running = True

while running:
    pygame.event.set_blocked(pygame.MOUSEWHEEL)
    WIDTH, HEIGHT = screen.get_size()
    bg_scaled = pygame.transform.smoothscale(background, (WIDTH, HEIGHT))
    screen.blit(bg_scaled, (0, 0))

    # --- marquee positions (top three + bottom begin) ---
    dotcom_y = 40
    wj_y = 90
    art_y = 140
    begin_y = HEIGHT - TASKBAR_HEIGHT - WINDOWS_TASKBAR_OFFSET + 10

    # --- update scroll (alternate directions, stop on hover) ---
    # BEGIN: left-to-right
    begin_scroll_x += 0.3 if not begin_hover else 0
    # Dot Com: right-to-left
    dotcom_scroll_x -= 0.4 if not dotcom_hover else 0
    # Writer's Jumbler: left-to-right
    wj_scroll_x += 0.4 if not wj_hover else 0
    # Jumbler Art: right-to-left
    art_scroll_x -= 0.4 if not art_hover else 0

    # --- draw marquees ---
    dotcom_scroll_x = draw_marquee(screen, MENUS[0][1], dotcom_scroll_x, "dotcom", dotcom_y)
    wj_scroll_x = draw_marquee(screen, MENUS[1][1], wj_scroll_x, "wj", wj_y)
    art_scroll_x = draw_marquee(screen, MENUS[2][1], art_scroll_x, "art", art_y)
    begin_scroll_x = draw_marquee(screen, BEGIN_MENU, begin_scroll_x, "begin", begin_y)

    # --- update scroll (all obey checkbox) ---
    if scroll_enabled:
        begin_scroll_x += 0.01 if not begin_hover else 0
        dotcom_scroll_x -= 0.01 if not dotcom_hover else 0
        wj_scroll_x += 0.01 if not wj_hover else 0
        art_scroll_x -= 0.01 if not art_hover else 0

    draw_taskbar_datetime(screen)

    # ---------------- EVENT LOOP ----------------
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if event.button != 1:
                continue   # ignore right-click, middle-click, scroll wheel
            # click detection for all marquees
            def handle_click(items, scroll_x, y):
                cycle_width = len(items) * 210
                scroll_x = scroll_x % cycle_width
                for copy in range(3):
                    x = 10 - scroll_x + (copy * cycle_width)
                    for name, path in items:
                        item_rect = pygame.Rect(x, y, 200, 30)
                        if item_rect.collidepoint(event.pos):
                            launch_app(path)
                            return True
                        x += 210
                return False

            # Dot Com
            if handle_click(MENUS[0][1], dotcom_scroll_x, dotcom_y):
                continue
            # Writer's Jumbler
            if handle_click(MENUS[1][1], wj_scroll_x, wj_y):
                continue
            # Jumbler Art
            if handle_click(MENUS[2][1], art_scroll_x, art_y):
                continue
            # BEGIN
            handle_click(BEGIN_MENU, begin_scroll_x, begin_y)

    pygame.display.flip()

pygame.quit()
