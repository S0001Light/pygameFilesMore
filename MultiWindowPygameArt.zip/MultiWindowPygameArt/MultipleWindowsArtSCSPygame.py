import subprocess

files = [
    "dots.py",
    "rectangles.py",
    "linesx.py",
    "vertical.py",
    "horizontal.py",
    "unique.py"
]

for f in files:
    subprocess.Popen(["python", f])
