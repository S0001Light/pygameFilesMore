import os
import math
import json
import time
import datetime
import subprocess
import threading
import urllib.parse
import urllib.request

import pygame
from PIL import Image

try:
    import win32com.client
except ImportError:
    win32com = None

pygame.init()

# ============================================================
# WINDOW / FILES
# ============================================================

screen = pygame.display.set_mode((1280, 700), pygame.RESIZABLE)
pygame.display.set_caption("Multi Launcher")
clock = pygame.time.Clock()

BASE_DIR = r"C:\Users\spenc\Downloads\wjLauncher5"
ICON_PATH = os.path.join(BASE_DIR, "icon1.ico")
GIF_PATH = os.path.join(BASE_DIR, "background.gif")
FALLBACK_BACKGROUND_PATH = os.path.join(BASE_DIR, "background2.png")

# Change this one line to change weather location.
# Examples: "Wichita, KS", "Dallas, TX", "Denver, CO"
WEATHER_LOCATION = "Wellington, KS"
WEATHER_REFRESH_SECONDS = 600

begin_icon = pygame.image.load(ICON_PATH).convert_alpha()
begin_icon = pygame.transform.smoothscale(begin_icon, (32, 32))

# ============================================================
# FONTS / COLORS
# ============================================================

FONT = pygame.font.SysFont("arial", 26)
ITEM_FONT = pygame.font.SysFont("arial", 22)
DATE_FONT = pygame.font.SysFont("arial", 18)
WEATHER_FONT = pygame.font.SysFont("arial", 20)

TEXT_COLOR = (220, 220, 255)
ITEM_TEXT_COLOR = (200, 200, 255)
MENU_COLOR = (30, 30, 30)
ITEM_COLOR = (40, 40, 40)
ITEM_HOVER_COLOR = (70, 70, 80)

TASKBAR_OPACITY = 140
BUTTON_OPACITY = 180
BUTTON_HOVER_OPACITY = 220
WEATHER_OPACITY = 150

# ============================================================
# MENU ITEMS
# ============================================================

BEGIN_MENU = [
    ("Windows Explorer", "explorer O:\\Pictures\\"),
    ("Microsoft Paint", "mspaint"),
    ("Adobe Photoshop CS2", "O:/Applications/AdobePhotoShopCS2/Photoshop.exe"),
    ("Gimp", "O:/Applications/GIMPPortable/GIMPPortable.exe"),
    ("Paint Dot Net", "O:/Applications/PaintDotNetPortable/PaintDotNetPortable.exe"),
    ("200 Art Animation", "O:/Applications/WritersJumbler_150_Art_Calc2.exe"),
    ("The Real Writer's Jumbler", "O:/Applications/Writers Jumbler Y - HTML/index.html"),
    ("Name A File", "O:/Applications/wjFileName/wjFileName.exe"),
    ("Block Art", "O:/Applications/wjBlockArt/wjBlockArt.exe"),
    ("Special Art", "D:/PortableAPPLICATIONS/wjSpecial25/wjSpecial25.exe"),
    ("Photo's Effects", "O:/Applications/wjPhotos/wjPhotos.exe"),
    ("Photo's Folder", "explorer O:\\Applications\\wjPhotos\\art"),
    ("Word Art and Shuffler", "O:/Applications/WritersJumbler_WordArt/WritersJumbler_WordArt.exe"),
    ("20-30 Animation", "O:/Applications/WritersJumbler-XandYanimation-20-30/WritersJumbler-XandYanimation-20-30.exe"),
    ("20-50 Art", "O:/Applications/WritersJumblerArt-20-50/WritersJumblerArt-20-50.exe"),
]

# ============================================================
# TASKBAR / SCROLL / ROLL SETTINGS
# ============================================================

TASKBAR_HEIGHT = 50
WINDOWS_TASKBAR_OFFSET = 40

BEGIN_WIDTH = 300
BEGIN_HEIGHT = 500
BEGIN_ITEM_TOP = 50
BEGIN_ITEM_HEIGHT = 30
BEGIN_ITEM_SPACING = 32
MENU_BOTTOM_PADDING = 10

menu_scroll = 0
MENU_SCROLL_SPEED = 32

start_menu_open = False
start_menu_animation = 0.0
ROLL_SPEED = 5.0
SLICE_HEIGHT = 3
CURL_STRENGTH = 18
PERSPECTIVE_STRENGTH = 0.18
SHADOW_STRENGTH = 100
RIPPLE_COUNT = 5.0
RIPPLE_SPEED = 9.0

# ============================================================
# GIF BACKGROUND
# ============================================================

def pil_to_pygame(image):
    rgba = image.convert("RGBA")
    return pygame.image.fromstring(rgba.tobytes(), rgba.size, "RGBA").convert_alpha()


def load_gif(path):
    frames = []
    durations = []
    with Image.open(path) as gif:
        for index in range(getattr(gif, "n_frames", 1)):
            gif.seek(index)
            frame = gif.convert("RGBA").copy()
            duration = max(20, int(gif.info.get("duration", 100) or 100))
            frames.append(pil_to_pygame(frame))
            durations.append(duration)
    if not frames:
        raise RuntimeError("GIF contains no readable frames")
    return frames, durations


if os.path.isfile(GIF_PATH):
    try:
        background_frames, background_durations = load_gif(GIF_PATH)
    except Exception as error:
        print("GIF error:", error)
        fallback = pygame.image.load(FALLBACK_BACKGROUND_PATH).convert()
        background_frames, background_durations = [fallback], [1000]
else:
    fallback = pygame.image.load(FALLBACK_BACKGROUND_PATH).convert()
    background_frames, background_durations = [fallback], [1000]

background_frame_index = 0
background_timer_ms = 0.0
scaled_background_frames = []
scaled_background_size = None


def rebuild_scaled_backgrounds(size):
    global scaled_background_frames, scaled_background_size
    scaled_background_frames = [pygame.transform.smoothscale(frame, size) for frame in background_frames]
    scaled_background_size = size


def update_gif(delta_ms):
    global background_frame_index, background_timer_ms
    count = len(background_frames)
    if not count:
        return
    background_frame_index %= count
    background_timer_ms += delta_ms
    safety = 0
    while safety < count:
        duration = background_durations[background_frame_index]
        if background_timer_ms < duration:
            break
        background_timer_ms -= duration
        background_frame_index = (background_frame_index + 1) % count
        safety += 1
    if safety == count:
        background_timer_ms = 0.0


def draw_gif_background(surface):
    global scaled_background_size
    size = surface.get_size()
    if scaled_background_size != size:
        rebuild_scaled_backgrounds(size)
    if scaled_background_frames:
        index = background_frame_index % len(scaled_background_frames)
        surface.blit(scaled_background_frames[index], (0, 0))

# ============================================================
# LIVE WEATHER
# Uses Open-Meteo geocoding + forecast APIs.
# Edit WEATHER_LOCATION above to change the city.
# ============================================================

weather_text = "Weather: loading..."
weather_lock = threading.Lock()
weather_refresh_running = False
last_weather_refresh = 0.0

WEATHER_CODES = {
    0: "Clear",
    1: "Mostly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Rime fog",
    51: "Light drizzle",
    53: "Drizzle",
    55: "Heavy drizzle",
    56: "Freezing drizzle",
    57: "Heavy freezing drizzle",
    61: "Light rain",
    63: "Rain",
    65: "Heavy rain",
    66: "Freezing rain",
    67: "Heavy freezing rain",
    71: "Light snow",
    73: "Snow",
    75: "Heavy snow",
    77: "Snow grains",
    80: "Light showers",
    81: "Showers",
    82: "Heavy showers",
    85: "Snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm / hail",
    99: "Heavy thunderstorm / hail",
}


def http_json(url):
    request = urllib.request.Request(url, headers={"User-Agent": "wjLauncher/1.0"})
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_weather():
    global weather_text, weather_refresh_running, last_weather_refresh
    try:
        query = urllib.parse.urlencode({
            "name": WEATHER_LOCATION,
            "count": 1,
            "language": "en",
            "format": "json",
            "countryCode": "US",
        })
        geo = http_json("https://geocoding-api.open-meteo.com/v1/search?" + query)
        results = geo.get("results") or []
        if not results:
            raise RuntimeError("location not found")

        place = results[0]
        latitude = place["latitude"]
        longitude = place["longitude"]
        display_name = place.get("name", WEATHER_LOCATION)
        admin = place.get("admin1", "")
        if admin:
            display_name += ", " + admin

        forecast_query = urllib.parse.urlencode({
            "latitude": latitude,
            "longitude": longitude,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m",
            "temperature_unit": "fahrenheit",
            "wind_speed_unit": "mph",
            "timezone": "auto",
        })
        data = http_json("https://api.open-meteo.com/v1/forecast?" + forecast_query)
        current = data.get("current") or {}

        temperature = current.get("temperature_2m", "--")
        feels = current.get("apparent_temperature", "--")
        humidity = current.get("relative_humidity_2m", "--")
        wind = current.get("wind_speed_10m", "--")
        direction = current.get("wind_direction_10m", "--")
        code = current.get("weather_code")
        conditions = WEATHER_CODES.get(code, "Weather code " + str(code) if code is not None else "Unknown")

        new_text = (
            f"{display_name}   |   {temperature} F   |   {conditions}   |   "
            f"Feels like {feels} F   |   Humidity {humidity}%   |   "
            f"Wind {wind} mph / {direction} deg"
        )
        with weather_lock:
            weather_text = new_text

    except Exception as error:
        with weather_lock:
            weather_text = f"{WEATHER_LOCATION}   |   Weather unavailable   |   {error}"
    finally:
        last_weather_refresh = time.monotonic()
        weather_refresh_running = False


def start_weather_refresh(force=False):
    global weather_refresh_running
    if weather_refresh_running:
        return
    if not force and time.monotonic() - last_weather_refresh < WEATHER_REFRESH_SECONDS:
        return
    weather_refresh_running = True
    threading.Thread(target=fetch_weather, daemon=True).start()


def draw_weather_ticker(surface):
    width, height = surface.get_size()
    y = height - WINDOWS_TASKBAR_OFFSET
    ticker = pygame.Surface((width, WINDOWS_TASKBAR_OFFSET), pygame.SRCALPHA)
    ticker.fill((15, 20, 35, WEATHER_OPACITY))
    with weather_lock:
        text_value = weather_text
    text = WEATHER_FONT.render(text_value, True, (220, 230, 255))
    ticker.blit(text, (15, (WINDOWS_TASKBAR_OFFSET - text.get_height()) // 2))
    surface.blit(ticker, (0, y))

# ============================================================
# HELPERS
# ============================================================

def get_taskbar_y():
    return screen.get_height() - TASKBAR_HEIGHT - WINDOWS_TASKBAR_OFFSET


def get_menu_rect():
    return pygame.Rect(0, get_taskbar_y() - BEGIN_HEIGHT, BEGIN_WIDTH, BEGIN_HEIGHT)


def get_item_clip_local():
    return pygame.Rect(10, BEGIN_ITEM_TOP, BEGIN_WIDTH - 30, BEGIN_HEIGHT - BEGIN_ITEM_TOP - MENU_BOTTOM_PADDING)


def get_max_menu_scroll():
    if not BEGIN_MENU:
        return 0
    content_bottom = BEGIN_ITEM_TOP + (len(BEGIN_MENU) - 1) * BEGIN_ITEM_SPACING + BEGIN_ITEM_HEIGHT
    return max(0, content_bottom - (BEGIN_HEIGHT - MENU_BOTTOM_PADDING))


def scroll_menu(amount):
    global menu_scroll
    menu_scroll = max(0, min(menu_scroll + amount, get_max_menu_scroll()))


def get_roll_amount():
    if start_menu_open:
        return 1.0 - (1.0 - start_menu_animation) ** 3
    return start_menu_animation ** 3

# ============================================================
# LAUNCH APPLICATION
# ============================================================

def launch_app(path):
    try:
        if path.lower().startswith("explorer "):
            subprocess.Popen(["explorer", path[len("explorer "):].strip().strip('"')])
            return
        if os.path.isdir(path):
            subprocess.Popen(["explorer", path])
            return
        if path.lower().endswith(".lnk"):
            if win32com is None:
                raise RuntimeError("Install pywin32 to open .lnk shortcuts")
            shell = win32com.client.Dispatch("WScript.Shell")
            shortcut = shell.CreateShortcut(path)
            command = [shortcut.TargetPath]
            if shortcut.Arguments:
                command.append(shortcut.Arguments)
            subprocess.Popen(command, cwd=shortcut.WorkingDirectory or None)
            return
        if path.lower().endswith((".html", ".htm")):
            os.startfile(path)
            return
        subprocess.Popen(path, shell=True)
    except Exception as error:
        print("Could not launch:", path, error)

# ============================================================
# TASKBAR
# ============================================================

def draw_taskbar(surface):
    width = surface.get_width()
    y = get_taskbar_y()

    bar = pygame.Surface((width, TASKBAR_HEIGHT), pygame.SRCALPHA)
    bar.fill((20, 20, 20, TASKBAR_OPACITY))
    surface.blit(bar, (0, y))
    pygame.draw.line(surface, (90, 90, 110), (0, y), (width, y), 2)

    begin_rect = pygame.Rect(0, y, 210, TASKBAR_HEIGHT)
    hovered = begin_rect.collidepoint(pygame.mouse.get_pos())
    button = pygame.Surface(begin_rect.size, pygame.SRCALPHA)
    if hovered:
        button.fill((60, 60, 75, BUTTON_HOVER_OPACITY))
    else:
        button.fill((40, 40, 40, BUTTON_OPACITY))
    surface.blit(button, begin_rect.topleft)

    surface.blit(begin_icon, (10, y + 9))
    surface.blit(FONT.render("Dragon's Lair", True, TEXT_COLOR), (50, y + 10))

    now = datetime.datetime.now()
    time_text = FONT.render(now.strftime("%I:%M %p"), True, TEXT_COLOR)
    date_text = DATE_FONT.render(now.strftime("%b %d, %Y"), True, (180, 180, 220))
    surface.blit(time_text, (width - time_text.get_width() - 15, y + 2))
    surface.blit(date_text, (width - date_text.get_width() - 15, y + 28))
    return begin_rect

# ============================================================
# MENU DRAWING
# ============================================================

def build_begin_menu_surface():
    menu_surface = pygame.Surface((BEGIN_WIDTH, BEGIN_HEIGHT), pygame.SRCALPHA)
    pygame.draw.rect(menu_surface, (*MENU_COLOR, 250), (0, 0, BEGIN_WIDTH, BEGIN_HEIGHT), border_radius=6)
    pygame.draw.rect(menu_surface, (100, 100, 125, 255), (0, 0, BEGIN_WIDTH, BEGIN_HEIGHT), 3, border_radius=6)
    pygame.draw.rect(menu_surface, (35, 40, 80, 255), (3, 3, 10, BEGIN_HEIGHT - 6))
    menu_surface.blit(FONT.render("Dragon's Eye", True, TEXT_COLOR), (22, 10))
    pygame.draw.line(menu_surface, (90, 90, 130), (18, 43), (BEGIN_WIDTH - 15, 43), 2)

    mouse = pygame.mouse.get_pos()
    menu_top = get_taskbar_y() - BEGIN_HEIGHT
    item_clip = get_item_clip_local()
    old_clip = menu_surface.get_clip()
    menu_surface.set_clip(item_clip)

    for index, (name, path) in enumerate(BEGIN_MENU):
        item_y = BEGIN_ITEM_TOP + index * BEGIN_ITEM_SPACING - menu_scroll
        item_rect = pygame.Rect(10, item_y, BEGIN_WIDTH - 30, BEGIN_ITEM_HEIGHT)
        screen_rect = item_rect.move(0, menu_top)
        hovered = item_rect.colliderect(item_clip) and start_menu_animation >= 0.98 and screen_rect.collidepoint(mouse)
        pygame.draw.rect(menu_surface, ITEM_HOVER_COLOR if hovered else ITEM_COLOR, item_rect, border_radius=4)
        text = ITEM_FONT.render(name, True, ITEM_TEXT_COLOR)
        menu_surface.blit(text, (item_rect.x + 8, item_rect.y + 4))

    menu_surface.set_clip(old_clip)

    max_scroll = get_max_menu_scroll()
    if max_scroll > 0:
        track = pygame.Rect(BEGIN_WIDTH - 14, BEGIN_ITEM_TOP, 7, BEGIN_HEIGHT - BEGIN_ITEM_TOP - MENU_BOTTOM_PADDING)
        pygame.draw.rect(menu_surface, (20, 20, 25), track, border_radius=4)
        thumb_height = max(35, int(track.height * track.height / (track.height + max_scroll)))
        thumb_y = track.y + int((track.height - thumb_height) * (menu_scroll / max_scroll))
        pygame.draw.rect(menu_surface, (110, 110, 145), (track.x, thumb_y, track.width, thumb_height), border_radius=4)
    return menu_surface


def draw_rolled_begin_menu(surface):
    if start_menu_animation <= 0.001:
        return
    menu_surface = build_begin_menu_surface()
    taskbar_y = get_taskbar_y()
    visible_height = int(BEGIN_HEIGHT * max(0.0, min(get_roll_amount(), 1.0)))
    if visible_height <= 0:
        return

    source_start_y = BEGIN_HEIGHT - visible_height
    destination_top = taskbar_y - visible_height

    for source_y in range(source_start_y, BEGIN_HEIGHT, SLICE_HEIGHT):
        slice_height = min(SLICE_HEIGHT, BEGIN_HEIGHT - source_y)
        strip = menu_surface.subsurface(pygame.Rect(0, source_y, BEGIN_WIDTH, slice_height)).copy()
        relative_y = (source_y - source_start_y) / max(1, visible_height)
        curl_zone = (1.0 - relative_y) ** 1.25
        wave = math.sin(relative_y * math.pi * 2.0 * RIPPLE_COUNT + start_menu_animation * RIPPLE_SPEED)
        x_offset = int(wave * CURL_STRENGTH * curl_zone)
        perspective = 1.0 - PERSPECTIVE_STRENGTH * curl_zone + math.sin(curl_zone * math.pi) * 0.05
        strip_width = max(1, int(BEGIN_WIDTH * perspective))
        scaled_height = max(1, int(slice_height * (1.0 - 0.28 * curl_zone)))
        strip = pygame.transform.smoothscale(strip, (strip_width, scaled_height))
        centered_x = (BEGIN_WIDTH - strip_width) // 2
        destination_y = destination_top + source_y - source_start_y
        vertical_curl = int(math.sin(curl_zone * math.pi) * 8 * curl_zone)
        surface.blit(strip, (centered_x + x_offset, destination_y + vertical_curl))


def update_start_menu_animation(delta_seconds):
    global start_menu_animation
    direction = 1 if start_menu_open else -1
    start_menu_animation = max(0.0, min(1.0, start_menu_animation + direction * ROLL_SPEED * delta_seconds))


def handle_begin_menu_click(mouse_position):
    if not start_menu_open or start_menu_animation < 0.95:
        return False
    menu_top = get_taskbar_y() - BEGIN_HEIGHT
    if not get_item_clip_local().move(0, menu_top).collidepoint(mouse_position):
        return False
    for index, (name, path) in enumerate(BEGIN_MENU):
        y = menu_top + BEGIN_ITEM_TOP + index * BEGIN_ITEM_SPACING - menu_scroll
        if pygame.Rect(10, y, BEGIN_WIDTH - 30, BEGIN_ITEM_HEIGHT).collidepoint(mouse_position):
            launch_app(path)
            return True
    return False

# ============================================================
# MAIN LOOP
# ============================================================

start_weather_refresh(force=True)
running = True

while running:
    delta_ms = clock.tick(60)
    delta_seconds = delta_ms / 1000.0

    update_gif(delta_ms)
    update_start_menu_animation(delta_seconds)
    start_weather_refresh()

    draw_gif_background(screen)
    draw_rolled_begin_menu(screen)
    begin_rect = draw_taskbar(screen)
    draw_weather_ticker(screen)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                start_menu_open = False
            elif start_menu_open and event.key == pygame.K_UP:
                scroll_menu(-MENU_SCROLL_SPEED)
            elif start_menu_open and event.key == pygame.K_DOWN:
                scroll_menu(MENU_SCROLL_SPEED)
            elif start_menu_open and event.key == pygame.K_HOME:
                menu_scroll = 0
            elif start_menu_open and event.key == pygame.K_END:
                menu_scroll = get_max_menu_scroll()
            # F5 forces an immediate weather refresh.
            elif event.key == pygame.K_F5:
                start_weather_refresh(force=True)

        elif event.type == pygame.MOUSEWHEEL:
            if start_menu_open and get_menu_rect().collidepoint(pygame.mouse.get_pos()):
                scroll_menu(-event.y * MENU_SCROLL_SPEED)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if begin_rect.collidepoint(event.pos):
                start_menu_open = not start_menu_open
                continue
            if handle_begin_menu_click(event.pos):
                start_menu_open = False
                continue
            if start_menu_open and start_menu_animation >= 0.95 and not get_menu_rect().collidepoint(event.pos):
                start_menu_open = False

    pygame.display.flip()

pygame.quit()
