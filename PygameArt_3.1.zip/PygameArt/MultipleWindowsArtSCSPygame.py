import tkinter as tk
import subprocess
import sys
import os

# Ensure correct working directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

python_exec = sys.executable

files = {
    "Dots": "dots.py",
    "Rectangles": "rectangles.py",
    "Lines X": "linesx.py",
    "Vertical": "vertical.py",
    "Horizontal": "horizontal.py",
    "Unique": "unique.py"
}

def launch_script(script_name):
    script_path = os.path.join(BASE_DIR, script_name)
    subprocess.Popen(
        [python_exec, script_path],
        cwd=BASE_DIR,
        start_new_session=True   # macOS-safe window isolation
    )

def launch_all():
    for script_name in files.values():
        launch_script(script_name)

# ---------------- GUI ----------------

root = tk.Tk()
root.title("Photos")
root.geometry("300x360")
root.configure(bg="#222222")

title = tk.Label(root, text="Photos by 10", fg="white", bg="#222222", font=("Arial", 16))
title.pack(pady=10)

for label, script in files.items():
    btn = tk.Button(
        root,
        text=label,
        width=20,
        height=2,
        command=lambda s=script: launch_script(s)
    )
    btn.pack(pady=5)

run_all_btn = tk.Button(
    root,
    text="Run ALL",
    width=20,
    height=2,
    bg="#444444",
    fg="white",
    command=launch_all
)
run_all_btn.pack(pady=15)

root.mainloop()
