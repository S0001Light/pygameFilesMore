import pygame
from pygame.locals import *
from random import *
from sys import exit
import sys
import datetime

pygame.init()
screen = pygame.display.set_mode((640, 640), 0, 32)

def row0():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (0, y)
    two_rct_size = (0, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row1():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (10, y)
    two_rct_size = (10, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row2():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (20, y)
    two_rct_size = (20, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row3():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (30, y)
    two_rct_size = (30, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row4():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (40, y)
    two_rct_size = (40, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row5():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (50, y)
    two_rct_size = (50, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row6():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (60, y)
    two_rct_size = (60, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row7():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (70, y)
    two_rct_size = (70, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row8():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (80, y)
    two_rct_size = (80, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row9():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (90, y)
    two_rct_size = (90, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row10():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (100, y)
    two_rct_size = (100, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row11():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (110, y)
    two_rct_size = (110, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row12():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (120, y)
    two_rct_size = (120, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row13():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (130, y)
    two_rct_size = (130, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row14():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (140, y)
    two_rct_size = (140, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row15():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (150, y)
    two_rct_size = (150, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row16():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (160, y)
    two_rct_size = (160, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row17():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (170, y)
    two_rct_size = (170, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row18():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (180, y)
    two_rct_size = (180, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row19():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (190, y)
    two_rct_size = (190, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row20():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (200, y)
    two_rct_size = (200, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row21():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (210, y)
    two_rct_size = (210, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row22():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (220, y)
    two_rct_size = (220, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row23():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (230, y)
    two_rct_size = (230, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row24():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (240, y)
    two_rct_size = (240, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row25():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (250, y)
    two_rct_size = (250, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row26():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (260, y)
    two_rct_size = (260, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row27():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (270, y)
    two_rct_size = (270, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row28():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (280, y)
    two_rct_size = (280, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row29():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (290, y)
    two_rct_size = (290, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row30():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (300, y)
    two_rct_size = (300, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row31():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (310, y)
    two_rct_size = (310, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row32():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (320, y)
    two_rct_size = (320, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row33():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (330, y)
    two_rct_size = (330, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row34():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (340, y)
    two_rct_size = (340, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row35():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (350, y)
    two_rct_size = (350, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row36():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (360, y)
    two_rct_size = (360, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row37():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (370, y)
    two_rct_size = (370, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row38():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (380, y)
    two_rct_size = (380, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row39():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (390, y)
    two_rct_size = (390, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row40():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (400, y)
    two_rct_size = (400, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row41():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (410, y)
    two_rct_size = (410, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row42():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (420, y)
    two_rct_size = (420, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row43():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (430, y)
    two_rct_size = (430, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row44():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (440, y)
    two_rct_size = (440, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row45():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (450, y)
    two_rct_size = (450, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row46():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (460, y)
    two_rct_size = (460, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row47():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (470, y)
    two_rct_size = (470, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row48():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (480, y)
    two_rct_size = (480, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row49():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (490, y)
    two_rct_size = (490, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row50():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (500, y)
    two_rct_size = (500, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row51():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (510, y)
    two_rct_size = (510, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row52():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (520, y)
    two_rct_size = (520, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row53():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (530, y)
    two_rct_size = (530, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row54():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (540, y)
    two_rct_size = (540, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row55():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (550, y)
    two_rct_size = (550, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row56():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (560, y)
    two_rct_size = (560, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row57():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (570, y)
    two_rct_size = (570, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row58():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (580, y)
    two_rct_size = (580, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row59():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (590, y)
    two_rct_size = (590, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row60():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (600, y)
    two_rct_size = (600, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row61():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (610, y)
    two_rct_size = (610, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row62():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (620, y)
    two_rct_size = (620, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row63():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (630, y)
    two_rct_size = (630, y+0.1)
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def row64():
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (640, y)
    two_rct_size = (640, y+0.1)
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    return

def dotArtwork():

    row0()
    row1()
    row2()
    row3()
    row4()
    row5()
    row6()
    row7()
    row8()
    row9()
    row10()
    row11()
    row12()
    row13()
    row14()
    row15()
    row16()
    row17()
    row18()
    row19()
    row20()
    row21()
    row22()
    row23()
    row24()
    row25()
    row26()
    row27()
    row28()
    row29()
    row30()
    row31()
    row32()
    row33()
    row34()
    row35()
    row36()
    row37()
    row38()
    row39()
    row40()
    row41()
    row42()
    row43()
    row44()
    row45()
    row46()
    row47()
    row48()
    row49()
    row50()
    row51()
    row52()
    row53()
    row54()
    row55()
    row56()
    row57()
    row58()
    row59()
    row60()
    row61()
    row62()
    row63()
    row64()

def saveAsBMP():

    word = "DOTartwork_Rndm_"
    dthm = datetime.datetime.now()
    m = str(dthm.strftime("%m"))
    dy = str(dthm.strftime("%d"))
    y = str(dthm.strftime("%Y"))
    h = str(dthm.strftime("%I"))
    mins = str(dthm.strftime("%M"))
    amPm = str(dthm.strftime("%p"))
    sec = str(dthm.strftime("%S"))
    dash = "-"
    d = str(m + dash + dy + dash + y + dash + h + dash + mins + dash + sec + dash + amPm)
    zS = word + d + ".bmp"
    getImage = screen
    pygame.image.save(getImage, zS)
    return
while True:

    for event in pygame.event.get():
        if event.type == QUIT:
            exit()
        if event.type == KEYDOWN:
            if event.key == K_q:
                screen.fill((0,0,0))
                dotArtwork()
                saveAsBMP()
    
    pygame.display.update()

