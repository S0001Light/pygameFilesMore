import pygame
from pygame.locals import *
from sys import exit
from random import *
from random import randint
import sys
import datetime

pygame.init()
screen = pygame.display.set_mode((640, 640), 0, 32)

def rect0001():
        
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (0, y)
    pointSet2 = (640, y)
    pointSet3 = (640, x)
    pointSet4 = (0, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)
    
    return

def rect0002():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (10, y)
    pointSet2 = (630, y)
    pointSet3 = (630, x)
    pointSet4 = (10, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)
    
    return

def rect0003():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (20, y)
    pointSet2 = (620, y)
    pointSet3 = (620, x)
    pointSet4 = (20, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)
    
    return

def rect0004():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (30, y)
    pointSet2 = (610, y)
    pointSet3 = (610, x)
    pointSet4 = (30, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0005():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (40, y)
    pointSet2 = (600, y)
    pointSet3 = (600, x)
    pointSet4 = (40, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0006():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (50, y)
    pointSet2 = (590, y)
    pointSet3 = (590, x)
    pointSet4 = (50, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0007():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (60, y)
    pointSet2 = (580, y)
    pointSet3 = (580, x)
    pointSet4 = (60, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0008():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (70, y)
    pointSet2 = (570, y)
    pointSet3 = (570, x)
    pointSet4 = (70, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0009():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (80, y)
    pointSet2 = (560, y)
    pointSet3 = (560, x)
    pointSet4 = (80, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0010():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (90, y)
    pointSet2 = (550, y)
    pointSet3 = (550, x)
    pointSet4 = (90, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0011():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (100, y)
    pointSet2 = (540, y)
    pointSet3 = (540, x)
    pointSet4 = (100, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0012():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (110, y)
    pointSet2 = (530, y)
    pointSet3 = (530, x)
    pointSet4 = (110, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0013():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (120, y)
    pointSet2 = (520, y)
    pointSet3 = (520, x)
    pointSet4 = (120, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0014():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (130, y)
    pointSet2 = (510, y)
    pointSet3 = (510, x)
    pointSet4 = (130, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0015():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (140, y)
    pointSet2 = (500, y)
    pointSet3 = (500, x)
    pointSet4 = (140, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0016():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (150, y)
    pointSet2 = (490, y)
    pointSet3 = (490, x)
    pointSet4 = (150, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0017():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (160, y)
    pointSet2 = (480, y)
    pointSet3 = (480, x)
    pointSet4 = (160, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0018():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (170, y)
    pointSet2 = (470, y)
    pointSet3 = (470, x)
    pointSet4 = (170, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0019():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (180, y)
    pointSet2 = (460, y)
    pointSet3 = (460, x)
    pointSet4 = (180, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0020():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (190, y)
    pointSet2 = (450, y)
    pointSet3 = (450, x)
    pointSet4 = (190, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0021():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (200, y)
    pointSet2 = (440, y)
    pointSet3 = (440, x)
    pointSet4 = (200, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0022():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (210, y)
    pointSet2 = (430, y)
    pointSet3 = (430, x)
    pointSet4 = (210, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0023():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (220, y)
    pointSet2 = (420, y)
    pointSet3 = (420, x)
    pointSet4 = (220, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0024():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (230, y)
    pointSet2 = (410, y)
    pointSet3 = (410, x)
    pointSet4 = (230, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0025():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (240, y)
    pointSet2 = (400, y)
    pointSet3 = (400, x)
    pointSet4 = (240, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0026():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (250, y)
    pointSet2 = (390, y)
    pointSet3 = (390, x)
    pointSet4 = (250, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0027():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (260, y)
    pointSet2 = (380, y)
    pointSet3 = (380, x)
    pointSet4 = (260, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0028():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (270, y)
    pointSet2 = (370, y)
    pointSet3 = (370, x)
    pointSet4 = (270, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0029():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (280, y)
    pointSet2 = (360, y)
    pointSet3 = (360, x)
    pointSet4 = (280, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0030():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (290, y)
    pointSet2 = (350, y)
    pointSet3 = (350, x)
    pointSet4 = (290, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0031():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (300, y)
    pointSet2 = (340, y)
    pointSet3 = (340, x)
    pointSet4 = (300, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0032():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (310, y)
    pointSet2 = (330, y)
    pointSet3 = (330, x)
    pointSet4 = (310, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0033():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (320, y)
    pointSet2 = (320, y)
    pointSet3 = (320, x)
    pointSet4 = (320, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0034():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (330, y)
    pointSet2 = (310, y)
    pointSet3 = (310, x)
    pointSet4 = (330, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0035():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (340, y)
    pointSet2 = (300, y)
    pointSet3 = (300, x)
    pointSet4 = (340, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0036():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (350, y)
    pointSet2 = (290, y)
    pointSet3 = (290, x)
    pointSet4 = (350, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0037():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (360, y)
    pointSet2 = (280, y)
    pointSet3 = (280, x)
    pointSet4 = (360, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0038():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (370, y)
    pointSet2 = (270, y)
    pointSet3 = (270, x)
    pointSet4 = (370, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0039():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (380, y)
    pointSet2 = (260, y)
    pointSet3 = (260, x)
    pointSet4 = (380, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0040():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (390, y)
    pointSet2 = (250, y)
    pointSet3 = (250, x)
    pointSet4 = (390, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0041():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (400, y)
    pointSet2 = (240, y)
    pointSet3 = (240, x)
    pointSet4 = (400, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0042():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (410, y)
    pointSet2 = (230, y)
    pointSet3 = (230, x)
    pointSet4 = (410, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0043():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (420, y)
    pointSet2 = (220, y)
    pointSet3 = (220, x)
    pointSet4 = (420, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0044():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (430, y)
    pointSet2 = (210, y)
    pointSet3 = (210, x)
    pointSet4 = (430, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0045():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (440, y)
    pointSet2 = (200, y)
    pointSet3 = (200, x)
    pointSet4 = (440, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0046():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (450, y)
    pointSet2 = (190, y)
    pointSet3 = (190, x)
    pointSet4 = (450, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0047():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (460, y)
    pointSet2 = (180, y)
    pointSet3 = (180, x)
    pointSet4 = (460, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0048():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (470, y)
    pointSet2 = (170, y)
    pointSet3 = (170, x)
    pointSet4 = (470, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0049():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (480, y)
    pointSet2 = (160, y)
    pointSet3 = (160, x)
    pointSet4 = (480, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0050():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (490, y)
    pointSet2 = (150, y)
    pointSet3 = (150, x)
    pointSet4 = (490, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0051():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (500, y)
    pointSet2 = (140, y)
    pointSet3 = (140, x)
    pointSet4 = (500, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0052():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (510, y)
    pointSet2 = (130, y)
    pointSet3 = (130, x)
    pointSet4 = (510, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0053():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (520, y)
    pointSet2 = (120, y)
    pointSet3 = (120, x)
    pointSet4 = (520, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0054():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (530, y)
    pointSet2 = (110, y)
    pointSet3 = (110, x)
    pointSet4 = (530, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0055():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (540, y)
    pointSet2 = (100, y)
    pointSet3 = (100, x)
    pointSet4 = (540, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0056():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (550, y)
    pointSet2 = (90, y)
    pointSet3 = (90, x)
    pointSet4 = (550, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0057():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (560, y)
    pointSet2 = (80, y)
    pointSet3 = (80, x)
    pointSet4 = (560, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0058():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (570, y)
    pointSet2 = (70, y)
    pointSet3 = (70, x)
    pointSet4 = (570, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0059():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (580, y)
    pointSet2 = (60, y)
    pointSet3 = (60, x)
    pointSet4 = (580, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0060():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (590, y)
    pointSet2 = (50, y)
    pointSet3 = (50, x)
    pointSet4 = (590, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0061():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (600, y)
    pointSet2 = (40, y)
    pointSet3 = (40, x)
    pointSet4 = (600, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0062():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (610, y)
    pointSet2 = (30, y)
    pointSet3 = (30, x)
    pointSet4 = (610, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0063():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (620, y)
    pointSet2 = (20, y)
    pointSet3 = (20, x)
    pointSet4 = (620, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)

    return

def rect0064():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (630, y)
    pointSet2 = (10, y)
    pointSet3 = (10, x)
    pointSet4 = (630, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)
    
    return

def rect0065():
    x = int(randint(0, 64) * 10.)
    y = int(randint(0, 64) * 10.)
    rct_color = (int(255),int(255),int(255))
    pointSet1 = (640, y)
    pointSet2 = (0, y)
    pointSet3 = (0, x)
    pointSet4 = (640, x)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet4),1)
    pygame.draw.line(screen, rct_color, (pointSet3), (pointSet2),1)
    pygame.draw.line(screen, rct_color, (pointSet1), (pointSet4),1)
    screen.set_at((pointSet1), rct_color)
    screen.set_at((pointSet2), rct_color)
    screen.set_at((pointSet3), rct_color)
    screen.set_at((pointSet4), rct_color)
    
    return



def segment001():
    rect0001()
    rect0002()
    rect0003()
    rect0004()
    rect0005()
    rect0006()
    rect0007()
    rect0008()
    rect0009()
    rect0010()
    return
def segment002():
    rect0011()
    rect0012()
    rect0013()
    rect0014()
    rect0015()
    rect0016()
    rect0017()
    rect0018()
    rect0019()
    rect0020()
    return
def segment003():
    rect0021()
    rect0022()
    rect0023()
    rect0024()
    rect0025()
    rect0026()
    rect0027()
    rect0028()
    rect0029()
    rect0030()
    return
def segment004():
    rect0031()
    rect0032()
    rect0033()
    rect0034()
    rect0035()
    rect0036()
    rect0037()
    rect0038()
    rect0039()
    rect0040()
    return
def segment005():
    rect0041()
    rect0042()
    rect0043()
    rect0044()
    rect0045()
    rect0046()
    rect0047()
    rect0048()
    rect0049()
    rect0050()
    return
def segment006():
    rect0051()
    rect0052()
    rect0053()
    rect0054()
    rect0055()
    rect0056()
    rect0057()
    rect0058()
    rect0059()
    rect0060()
    return
def segment007():
    rect0061()
    rect0062()
    rect0063()
    rect0064()
    rect0065()
    rect0033()
    rect0034()
    rect0035()
    rect0036()
    rect0037()
    return



def saveAsBMP():

    word = "DOT-Pixel-artwork_Rndm_"
    dthm = datetime.datetime.now()
    m = str(dthm.strftime("%m"))
    dy = str(dthm.strftime("%d"))
    y = str(dthm.strftime("%Y"))
    h = str(dthm.strftime("%I"))
    mins = str(dthm.strftime("%M"))
    amPm = str(dthm.strftime("%p"))
    sec = str(dthm.strftime("%S"))
    dash = "-"
    d = str(m + dash + dy + dash + y + dash + h + dash + mins + dash + sec + dash + amPm)
    zS = word + d + ".bmp"
    getImage = screen
    pygame.image.save(getImage, zS)
    return

while True:

    for event in pygame.event.get():
        if event.type == QUIT:
            exit()
        if event.type == KEYDOWN:
            if event.key == K_q:
                screen.fill((0,0,0))
                segment001()
                saveAsBMP()
            if event.key == K_w:
                screen.fill((0,0,0))
                segment002()
                saveAsBMP()
            if event.key == K_e:
                screen.fill((0,0,0))
                segment003()
                saveAsBMP()
            if event.key == K_r:
                screen.fill((0,0,0))
                segment004()
                saveAsBMP()
            if event.key == K_t:
                screen.fill((0,0,0))
                segment005()
                saveAsBMP()
            if event.key == K_y:
                screen.fill((0,0,0))
                segment006()
                saveAsBMP()
            if event.key == K_u:
                screen.fill((0,0,0))
                segment007()
                saveAsBMP()
                        
        pygame.display.update()
