import pygame
from pygame.locals import *
from random import *
from sys import exit
import sys
import datetime

pygame.init()
screen = pygame.display.set_mode((640, 640), 0, 32)
crcl_color = (int(0),int(0),int(0))

def row0():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (0, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (640, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row1():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (10, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (630, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row2():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (20, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (620, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row3():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (30, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (610, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row4():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (40, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (600, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row5():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (50, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (590, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row6():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (60, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (580, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row7():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (70, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (570, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row8():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (80, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (560, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row9():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (90, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (550, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row10():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (100, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (540, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row11():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (110, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (530, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row12():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (120, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (520, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row13():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (130, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (510, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row14():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (140, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (500, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row15():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (150, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (490, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row16():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (160, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (480, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row17():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (170, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (470, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row18():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (180, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (460, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row19():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (190, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (450, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row20():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (200, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (440, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row21():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (210, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (430, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row22():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (220, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (420, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row23():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (230, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (410, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row24():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (240, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (400, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row25():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (250, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (390, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row26():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (260, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (380, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row27():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (270, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (370, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row28():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (280, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (360, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row29():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (290, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (350, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row30():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (300, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (340, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row31():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (310, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (330, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row32():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (320, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (320, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row33():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (330, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (310, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row34():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (340, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (300, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row35():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (350, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (290, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row36():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (360, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (280, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row37():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (370, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (270, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row38():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (380, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (260, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row39():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (390, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (250, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row40():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (400, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (240, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row41():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (410, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (230, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row42():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (420, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (220, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row43():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (430, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (210, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row44():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (440, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (200, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row45():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (450, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (190, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row46():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (460, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (180, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row47():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (470, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (170, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row48():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (480, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (160, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row49():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (490, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (150, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row50():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (500, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (140, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row51():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (510, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (130, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row52():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (520, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (120, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row53():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (530, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (110, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row54():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (540, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (100, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row55():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (550, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (90, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row56():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (560, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (80, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row57():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (570, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (70, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row58():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (580, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (60, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row59():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (590, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (50, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row60():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (600, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (40, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row61():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (610, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (30, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row62():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (620, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (20, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row63():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (630, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (10, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def row64():
    y = int(randint(0, 64) * 10)

    one_crcl_pos = (640, y)
    circle_radius = int(4)
    pygame.draw.circle(screen, crcl_color, one_crcl_pos, circle_radius)
    two_crcl_pos = (0, y)
    pygame.draw.circle(screen, crcl_color, two_crcl_pos, circle_radius)
    return

def dotArtwork():

    row0()
    row1()
    row2()
    row3()
    row4()
    row5()
    row6()
    row7()
    row8()
    row9()
    row10()
    row11()
    row12()
    row13()
    row14()
    row15()
    row16()
    row17()
    row18()
    row19()
    row20()
    row21()
    row22()
    row23()
    row24()
    row25()
    row26()
    row27()
    row28()
    row29()
    row30()
    row31()
    row32()
    row33()
    row34()
    row35()
    row36()
    row37()
    row38()
    row39()
    row40()
    row41()
    row42()
    row43()
    row44()
    row45()
    row46()
    row47()
    row48()
    row49()
    row50()
    row51()
    row52()
    row53()
    row54()
    row55()
    row56()
    row57()
    row58()
    row59()
    row60()
    row61()
    row62()
    row63()
    row64()

def saveAsBMP():

    word = "DOTartwork_Rndm_"
    dthm = datetime.datetime.now()
    m = str(dthm.strftime("%m"))
    dy = str(dthm.strftime("%d"))
    y = str(dthm.strftime("%Y"))
    h = str(dthm.strftime("%I"))
    mins = str(dthm.strftime("%M"))
    amPm = str(dthm.strftime("%p"))
    sec = str(dthm.strftime("%S"))
    dash = "-"
    d = str(m + dash + dy + dash + y + dash + h + dash + mins + dash + sec + dash + amPm)
    zS = word + d + ".bmp"
    getImage = screen
    pygame.image.save(getImage, zS)
    return
while True:

    for event in pygame.event.get():
        if event.type == QUIT:
            exit()
        if event.type == KEYDOWN:
            if event.key == K_q:
                screen.fill((255,255,255))
                dotArtwork()
                saveAsBMP()
            if event.key == K_w:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_e:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_r:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_t:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_y:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_u:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_i:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_o:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
            if event.key == K_p:
                screen.fill((255,255,255))
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                dotArtwork()
                saveAsBMP()
                
                
                

    
    pygame.display.update()

