import subprocess
import os

base = r"C:\Users\spenc\Documents\PYgameArt2,0\1"

files = []

# Generate folders 1 through 5
for n in range(1, 6):
    path = fr"{base}\{n}\Pygame-Art-ALL6TypesPythonBMP-DCT-Dots-HTML2.py"
    files.append(path)

script_folder = os.path.dirname(os.path.abspath(__file__))

for f in files:
    subprocess.Popen(["python", f], cwd=script_folder)
