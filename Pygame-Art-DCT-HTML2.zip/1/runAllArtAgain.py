import subprocess
import os

base = r"C:\Users\spenc\Documents\PYgameArt2,0\1"

art_types = [
    "DOTartwork_Dots.py",
    "DOTartwork_Unique.py",
    "DOTartwork_Rectangles.py",
    "DOTartwork_X.py",
    "DOTartwork_Verticals.py",
    "DOTartwork_Horizontals.py"
]

files = []

# Generate folders 1 through 5
for n in range(1, 6):
    for art in art_types:
        path = fr"{base}\{n}\{art}"
        files.append(path)

script_folder = os.path.dirname(os.path.abspath(__file__))

for f in files:
    subprocess.Popen(["python", f], cwd=script_folder)
