whereever this folder is located with this file where you want your files and folders, rename in .bat

to get this to work change the location of the file to copy to each folder and file directory where you want all folders, with right click edit.

Now you can run the python file in order from each folder once to get all same type of image files

order to run:

Pygame-Art-All6TypesPythonBMP-DCT-Dots-HTML2.py

1/runAllArt.py

1/runAllArtAgain.py

check out all the photos in the folders