To get all this to work, edit six files.

dots.py
horizontal.py
linesx.py
rectangles.py
unique.py
vertical.py

copy this, add to replace:

C:\Users\spenc\Documents\scsPygameArt\MultiWindowPygameArt\MultiWindowPygameArt\

with:

C:\WHEREEVERTHEFILEISLOCATED\

And, then, open MultipleWindowsArtSCSPygame.py in python, and Run - Run Module.