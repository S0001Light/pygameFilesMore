import pygame
from pygame.locals import *
from random import *
from sys import exit
import sys
import datetime
pygame.init()
screen = pygame.display.set_mode((640, 640), 0, 32)
TIMER_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(TIMER_EVENT, 5000)
def dotArtwork6():
    word = r"C:\Users\spenc\Documents\scsPygameArt\MultiWindowPygameArt\MultiWindowPygameArt\Uniques\DOTartwork_Unique_Rndm_"
    dthm = datetime.datetime.now()
    m = str(dthm.strftime("%m"))
    dy = str(dthm.strftime("%d"))
    y = str(dthm.strftime("%Y"))
    h = str(dthm.strftime("%I"))
    mins = str(dthm.strftime("%M"))
    amPm = str(dthm.strftime("%p"))
    sec = str(dthm.strftime("%S"))
    dash = "-"
    d = str(m + dash + dy + dash + y + dash + h + dash + mins + dash + sec + dash + amPm)
    zT = word + d + ".py"
    file = open(zT, "w")
    file.write('import pygame' + "\n")
    file.write('from pygame.locals import *' + "\n")
    file.write('pygame.init()' + "\n")
    file.write('screen = pygame.display.set_mode((640, 640), 0, 32)' + "\n")
    file.write('rct_color = (int(255),int(255),int(255))' + "\n")
    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (0, y)
    two_rct_size = (0, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (10, y)
    two_rct_size = (10, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (20, y)
    two_rct_size = (20, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (30, y)
    two_rct_size = (30, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (40, y)
    two_rct_size = (40, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (50, y)
    two_rct_size = (50, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (60, y)
    two_rct_size = (60, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (70, y)
    two_rct_size = (70, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (80, y)
    two_rct_size = (80, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (90, y)
    two_rct_size = (90, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (100, y)
    two_rct_size = (100, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (110, y)
    two_rct_size = (110, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (120, y)
    two_rct_size = (120, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (130, y)
    two_rct_size = (130, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (140, y)
    two_rct_size = (140, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (150, y)
    two_rct_size = (150, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (160, y)
    two_rct_size = (160, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (170, y)
    two_rct_size = (170, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (180, y)
    two_rct_size = (180, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (190, y)
    two_rct_size = (190, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (200, y)
    two_rct_size = (200, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (210, y)
    two_rct_size = (210, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (220, y)
    two_rct_size = (220, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (230, y)
    two_rct_size = (230, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (240, y)
    two_rct_size = (240, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (250, y)
    two_rct_size = (250, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (260, y)
    two_rct_size = (260, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (270, y)
    two_rct_size = (270, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (280, y)
    two_rct_size = (280, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (290, y)
    two_rct_size = (290, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (300, y)
    two_rct_size = (300, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (310, y)
    two_rct_size = (310, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (320, y)
    two_rct_size = (320, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (330, y)
    two_rct_size = (330, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (340, y)
    two_rct_size = (340, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (350, y)
    two_rct_size = (350, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (360, y)
    two_rct_size = (360, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (370, y)
    two_rct_size = (370, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (380, y)
    two_rct_size = (380, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (390, y)
    two_rct_size = (390, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (400, y)
    two_rct_size = (400, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (410, y)
    two_rct_size = (410, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (420, y)
    two_rct_size = (420, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (430, y)
    two_rct_size = (430, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (440, y)
    two_rct_size = (440, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (450, y)
    two_rct_size = (450, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (460, y)
    two_rct_size = (460, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (470, y)
    two_rct_size = (470, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (480, y)
    two_rct_size = (480, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (490, y)
    two_rct_size = (490, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (500, y)
    two_rct_size = (500, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (510, y)
    two_rct_size = (510, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (520, y)
    two_rct_size = (520, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (530, y)
    two_rct_size = (530, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (540, y)
    two_rct_size = (540, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (550, y)
    two_rct_size = (550, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (560, y)
    two_rct_size = (560, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (570, y)
    two_rct_size = (570, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (580, y)
    two_rct_size = (580, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (590, y)
    two_rct_size = (590, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (600, y)
    two_rct_size = (600, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (610, y)
    two_rct_size = (610, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (620, y)
    two_rct_size = (620, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")

    y = int(randint(0, 64) * 10)
    rct_color = (int(255),int(255),int(255))
    one_rct_size = (630, y)
    two_rct_size = (630, int(y+0.1))
    pygame.draw.rect(screen, rct_color, Rect((one_rct_size), (two_rct_size)))
    file.write("pygame.draw.rect(screen, rct_color, Rect((" + str(one_rct_size) + "), (" + str(two_rct_size) + ")))" + "\n")
    file.write('pygame.display.update()' + "\n")
    file.close()
    return

def saveAsBMP6():
    # Use raw string for Windows paths
    base_path = r"C:\Users\spenc\Documents\scsPygameArt\MultiWindowPygameArt\MultiWindowPygameArt\Uniques"
    word = "DOTartwork_Rectangles_Rndm_"

    # Timestamp
    timestamp = datetime.datetime.now().strftime("%m-%d-%Y-%I-%M-%S-%p")

    # Full BMP path
    zS = f"{base_path}\\{word}{timestamp}.bmp"

    # HTML file path
    zQ = f"{base_path}\\{word}.html"

    # Save BMP
    pygame.image.save(screen, zS)

    # Append to HTML
    with open(zQ, "a") as file2:
        file2.write(f"<p>{zS}</p></br>\n")
        file2.write(f'<img src="{zS}">\n')

    return

a = 0
while True:


    for event in pygame.event.get():
        if event.type == QUIT:
            exit()
        if event.type == TIMER_EVENT:
            if a <= 50:
                screen.fill((0,0,0))
                dotArtwork6()
                saveAsBMP6()
                a += 1
            else:
                pygame.time.set_timer(TIMER_EVENT, 0)
                
    pygame.display.update()
