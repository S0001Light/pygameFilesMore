import pygame
import subprocess
import os
import sys

pygame.init()

WIDTH, HEIGHT = 1024, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Multi Launcher")

FONT = pygame.font.SysFont("arial", 26)
ITEM_FONT = pygame.font.SysFont("arial", 22)
logo = pygame.image.load("C:/Users/spenc/OneDrive/Desktop/Numbers/wjLauncher/wj.png").convert_alpha()
logo = pygame.transform.smoothscale(logo, (824, 300))

# ---------------- GRADIENT ----------------
def draw_vertical_gradient(surface, top_color, mid_color, bottom_color):
    half = HEIGHT // 2

    # Top → Middle (Green → Blue)
    for y in range(half):
        ratio = y / half
        r = int(top_color[0] * (1 - ratio) + mid_color[0] * ratio)
        g = int(top_color[1] * (1 - ratio) + mid_color[1] * ratio)
        b = int(top_color[2] * (1 - ratio) + mid_color[2] * ratio)
        pygame.draw.line(surface, (r, g, b), (0, y), (WIDTH, y))

    # Middle → Bottom (Blue → Black)
    for y in range(half, HEIGHT):
        ratio = (y - half) / (HEIGHT - half)
        r = int(mid_color[0] * (1 - ratio) + bottom_color[0] * ratio)
        g = int(mid_color[1] * (1 - ratio) + bottom_color[1] * ratio)
        b = int(mid_color[2] * (1 - ratio) + bottom_color[2] * ratio)
        pygame.draw.line(surface, (r, g, b), (0, y), (WIDTH, y))


# ---------------- FOUR MENUS ----------------
MENUS = [
    ("Dot Com", [
        ("Name A File", "D:/PortableAPPLICATIONS/wjFileName/wjFileName.exe"),
        ("Block Art", "D:/PortableAPPLICATIONS/wjBlockArt/wjBlockArt.exe"),
        ("Special Art", "D:/PortableAPPLICATIONS/wjSpecial25/wjSpecial25.exe"),
        ("Photo's Effects", "D:/PortableAPPLICATIONS/wjPhotos/wjPhotos.exe"),
        ("Photo's Folder", "explorer D:\\PortableAPPLICATIONS\\wjPhotos\\art"),
        ("Word Art and Shuffler", "D:/PortableAPPLICATIONS/wjShufflerAndWordArt/wjShufflerAndWordArt.exe"),
        ("20-30 Animation", "D:/PortableAPPLICATIONS/WritersJumbler-XandYanimation-20-30/WritersJumbler-XandYanimation-20-30.exe"),
        ("20-50 Art", "D:/PortableAPPLICATIONS/WritersJumblerArt-20-50/WritersJumblerArt-20-50.exe"),
    ]),
    ("Writer's Jumbler", [
        ("tkWJ1", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ1.exe"),
        ("tkWJ2", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ2.exe"),
        ("tkWJ3", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ3.exe"),
        ("tkWJ4", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ4.exe"),
        ("tkWJ5", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ5.exe"),
    ]),
    ("Jumbler Art", [
        ("25 Art Animation", "C:/Users/spenc/Documents/WritersJumblerPythonArt/dist/WritersJumbler_25_Grid.exe"),
        ("30 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani.exe"),
        ("50 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani.exe"),
        ("30 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani3_ColorCycleMCP.exe"),
        ("50 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani3_ColorCycleMCP.exe"),
        ("30 Art 4 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani4.exe"),
        ("50 Art 4 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani4.exe"),
        ("30 Art 5 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani5.exe"),
        ("50 Art 5 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani5.exe"),
        ("30 Art 6 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani6.exe"),
        ("50 Art 6 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani6.exe"),
        ("150 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView.exe"),
        ("150 Art 2 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView2.exe"),
        ("200 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_200_Art_Ani.exe"),
        ]),
]

menu_open = [False, False, False]

# ---------------- LAUNCH ----------------
def launch_app(path):
    if path.startswith("explorer "):
        subprocess.Popen(path.split(" ", 1))
    if os.path.exists(path):
        subprocess.Popen(path)
    else:
        print("Missing:", path)


# ---------------- DRAW MENU ----------------
def draw_menu(index, x, y):
    title, items = MENUS[index]
    rect = pygame.Rect(x, y, 220, 40)

    pygame.draw.rect(screen, (30, 30, 30), rect, border_radius=6)
    label = FONT.render(title + (" ▼" if not menu_open[index] else " ▲"), True, (220, 220, 255))
    screen.blit(label, (rect.x + 10, rect.y + 7))

    if menu_open[index]:
        item_y = rect.bottom
        for name, path in items:
            item_rect = pygame.Rect(rect.x, item_y, rect.width, 35)
            mouse = pygame.mouse.get_pos()
            hovered = item_rect.collidepoint(mouse)

            pygame.draw.rect(screen, (50, 50, 50) if hovered else (25, 25, 25), item_rect)
            item_label = ITEM_FONT.render(name, True, (200, 200, 255))
            screen.blit(item_label, (item_rect.x + 10, item_rect.y + 7))

            item_y += 35

    return rect

# ---------------- MAIN LOOP ----------------
running = True
while running:
    draw_vertical_gradient(screen, (0,255,0), (0,0,255), (0,0,0))
    # Perfect spacing for 1024 width
    logo_rect = logo.get_rect()
    logo_rect.midbottom = (WIDTH // 2, HEIGHT - 10)
    screen.blit(logo, logo_rect)

    menu_rects = [
        draw_menu(0, 20, 40),
        draw_menu(1, 300, 40),
        draw_menu(2, 580, 40),
    ]

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            # Toggle menus
            for i, rect in enumerate(menu_rects):
                if rect.collidepoint(event.pos):
                    menu_open[i] = not menu_open[i]

            # Handle item clicks
            for i, rect in enumerate(menu_rects):
                if menu_open[i]:
                    _, items = MENUS[i]
                    item_y = rect.bottom
                    for name, path in items:
                        item_rect = pygame.Rect(rect.x, item_y, rect.width, 35)
                        if item_rect.collidepoint(event.pos):
                            launch_app(path)
                        item_y += 35

    pygame.display.flip()

pygame.quit()
