import pygame
import subprocess
import os
import datetime
import win32com.client

pygame.init()

# ---------------- WINDOW ----------------
screen = pygame.display.set_mode((1280, 700), pygame.RESIZABLE)
WIDTH, HEIGHT = screen.get_size()
pygame.display.set_caption("Multi Launcher")

# ---------------- ICONS ----------------
begin_icon = pygame.image.load(
    "C:/Users/spenc/OneDrive/Desktop/Numbers/wjLauncher/icon1.ico"
).convert_alpha()
begin_icon = pygame.transform.smoothscale(begin_icon, (32, 32))

background = pygame.image.load(
    "C:/Users/spenc/OneDrive/Desktop/Numbers/wjLauncher/background2.png"
).convert()
background = pygame.transform.smoothscale(background, (1280, 700))

# ---------------- FONTS ----------------
FONT = pygame.font.SysFont("arial", 26)
ITEM_FONT = pygame.font.SysFont("arial", 22)

# ---------------- GRADIENT ----------------
def draw_vertical_gradient(surface, top_color, mid_color, bottom_color):
    half = HEIGHT // 2
    for y in range(half):
        ratio = y / half
        r = int(top_color[0] * (1 - ratio) + mid_color[0] * ratio)
        g = int(top_color[1] * (1 - ratio) + mid_color[1] * ratio)
        b = int(top_color[2] * (1 - ratio) + mid_color[2] * ratio)
        pygame.draw.line(surface, (r, g, b), (0, y), (WIDTH, y))

    for y in range(half, HEIGHT):
        ratio = (y - half) / (HEIGHT - half)
        r = int(mid_color[0] * (1 - ratio) + bottom_color[0] * ratio)
        g = int(mid_color[1] * (1 - ratio) + bottom_color[1] * ratio)
        b = int(mid_color[2] * (1 - ratio) + bottom_color[2] * ratio)
        pygame.draw.line(surface, (r, g, b), (0, y), (WIDTH, y))

# ---------------- MENUS ----------------
MENUS = [
    ("Dot Com", [
        ("Name A File", "D:/PortableAPPLICATIONS/wjFileName/wjFileName.exe"),
        ("Block Art", "D:/PortableAPPLICATIONS/wjBlockArt/wjBlockArt.exe"),
        ("Special Art", "D:/PortableAPPLICATIONS/wjSpecial25/wjSpecial25.exe"),
        ("Photo's Effects", "D:/PortableAPPLICATIONS/wjPhotos/wjPhotos.exe"),
        ("Photo's Folder", "explorer D:\\PortableAPPLICATIONS\\wjPhotos\\art"),
        ("Word Art and Shuffler", "D:/PortableAPPLICATIONS/wjShufflerAndWordArt/wjShufflerAndWordArt.exe"),
        ("20-30 Animation", "D:/PortableAPPLICATIONS/WritersJumbler-XandYanimation-20-30/WritersJumbler-XandYanimation-20-30.exe"),
        ("20-50 Art", "D:/PortableAPPLICATIONS/WritersJumblerArt-20-50/WritersJumblerArt-20-50.exe"),
    ]),
    ("Writer's Jumbler", [
        ("tkWJ1", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ1.exe"),
        ("tkWJ2", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ2.exe"),
        ("tkWJ3", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ3.exe"),
        ("tkWJ4", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ4.exe"),
        ("tkWJ5", "D:/PortableAPPLICATIONS/WritersJumbler/tkWJ5.exe"),
    ]),
    ("Jumbler Art", [
        ("25 Art Animation", "C:/Users/spenc/Documents/WritersJumblerPythonArt/dist/WritersJumbler_25_Grid.exe"),
        ("30 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani.exe"),
        ("50 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani.exe"),
        ("30 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani3_ColorCycleMCP.exe"),
        ("50 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani3_ColorCycleMCP.exe"),
        ("30 Art 4 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani4.exe"),
        ("50 Art 4 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani4.exe"),
        ("30 Art 5 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani5.exe"),
        ("50 Art 5 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani5.exe"),
        ("30 Art 6 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_30_Art_Ani6.exe"),
        ("50 Art 6 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_50_Art_Ani6.exe"),
        ("150 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView.exe"),
        ("150 Art 2 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView2.exe"),
        ("150 Art 3 Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_150_Art_Ani_49inchCurveToView3.exe"),
        ("200 Art Animation", "D:/PortableAPPLICATIONS/WritersJumblerArt/WritersJumbler_200_Art_Ani.exe"),
    ]),
]

menu_open = [False, False, False]

# ---------------- BEGIN MENU ----------------
BEGIN_MENU = [
    ("Windows Explorer", "explorer D:\\Pictures\\"),
    ("Microsoft Paint", "mspaint"),
    ("Adobe Photoshop CS2", "C:/Program Files (x86)/Adobe/Adobe Photoshop CS2/Photoshop.exe"),
    ("Paint Dot Net", "C:/Program Files/Paint,NET/paintdotnet.exe"),
]

# ---------------- LAUNCH ----------------
def launch_app(path):
    if os.path.isdir(path):
        subprocess.Popen(["explorer", path])
        return

    if path.lower().endswith(".lnk"):
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(path)
        path = shortcut.TargetPath

    subprocess.Popen(path, shell=True)

# ---------------- DRAW MENUS ----------------
def draw_menu(index, x, y):
    title, items = MENUS[index]
    rect = pygame.Rect(x, y, 220, 40)

    pygame.draw.rect(screen, (30, 30, 30), rect, border_radius=6)
    label = FONT.render(title + (" ▼" if not menu_open[index] else " ▲"), True, (220, 220, 255))
    screen.blit(label, (rect.x + 10, rect.y + 7))

    if menu_open[index]:
        item_y = rect.bottom
        for name, path in items:
            item_rect = pygame.Rect(rect.x, item_y, rect.width, 35)
            hovered = item_rect.collidepoint(pygame.mouse.get_pos())
            pygame.draw.rect(screen, (50, 50, 50) if hovered else (25, 25, 25), item_rect)
            screen.blit(ITEM_FONT.render(name, True, (200, 200, 255)), (item_rect.x + 10, item_rect.y + 7))
            item_y += 35

    return rect

# ---------------- TASKBAR ----------------
TASKBAR_HEIGHT = 50
WINDOWS_TASKBAR_OFFSET = 40

def draw_taskbar(surface):
    y = HEIGHT - TASKBAR_HEIGHT - WINDOWS_TASKBAR_OFFSET
    pygame.draw.rect(surface, (20, 20, 20), (0, y, WIDTH, TASKBAR_HEIGHT))

    begin_rect = pygame.Rect(0, y, 120, TASKBAR_HEIGHT)
    pygame.draw.rect(surface, (40, 40, 40), begin_rect)

    surface.blit(begin_icon, (begin_rect.x + 10, y + 10))
    surface.blit(FONT.render("Dragon's Eye", True, (220, 220, 255)), (begin_rect.x + 45, y + 10))

    now = datetime.datetime.now()
    surface.blit(FONT.render(now.strftime("%I:%M %p"), True, (220, 220, 255)), (WIDTH - 150, y + 5))
    surface.blit(FONT.render(now.strftime("%b %d, %Y"), True, (180, 180, 220)), (WIDTH - 150, y + 25))

    return begin_rect

# ---------------- BEGIN MENU DRAW ----------------
def draw_begin_menu(surface):
    menu_rect = pygame.Rect(
        0,
        HEIGHT - TASKBAR_HEIGHT - WINDOWS_TASKBAR_OFFSET - 500,
        300,
        500,
    )

    pygame.draw.rect(surface, (30, 30, 30), menu_rect)
    pygame.draw.rect(surface, (80, 80, 80), menu_rect, 3)

    y = menu_rect.y + 10
    surface.blit(FONT.render("Dragon's Lair", True, (220, 220, 255)), (menu_rect.x + 10, y))
    y += 40

    for name, path in BEGIN_MENU:
        item_rect = pygame.Rect(menu_rect.x + 10, y, 280, 30)
        hovered = item_rect.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(surface, (60, 60, 60) if hovered else (40, 40, 40), item_rect)
        surface.blit(ITEM_FONT.render(name, True, (200, 200, 255)), (item_rect.x + 8, item_rect.y + 5))
        y += 32

    return menu_rect

# ---------------- MAIN LOOP ----------------
start_menu_open = False
running = True

while running:
    WIDTH, HEIGHT = screen.get_size()
    bg_scaled = pygame.transform.smoothscale(background, (WIDTH, HEIGHT))
    screen.blit(bg_scaled, (0, 0))

    menu_rects = [
        draw_menu(0, 20, 40),
        draw_menu(1, 300, 40),
        draw_menu(2, 580, 40),
    ]

    begin_rect = draw_taskbar(screen)

    if start_menu_open:
        menu_rect = draw_begin_menu(screen)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            if begin_rect.collidepoint(event.pos):
                start_menu_open = not start_menu_open

            if start_menu_open:
                menu_rect = pygame.Rect(
                    0,
                    HEIGHT - TASKBAR_HEIGHT - WINDOWS_TASKBAR_OFFSET - 500,
                    300,
                    500,
                )
                y = menu_rect.y + 50

                for name, path in BEGIN_MENU:
                    item_rect = pygame.Rect(menu_rect.x + 10, y, 280, 30)
                    if item_rect.collidepoint(event.pos):
                        launch_app(path)
                    y += 32

            for i, rect in enumerate(menu_rects):
                if rect.collidepoint(event.pos):
                    menu_open[i] = not menu_open[i]

            for i, rect in enumerate(menu_rects):
                if menu_open[i]:
                    _, items = MENUS[i]
                    item_y = rect.bottom
                    for name, path in items:
                        item_rect = pygame.Rect(rect.x, item_y, rect.width, 35)
                        if item_rect.collidepoint(event.pos):
                            launch_app(path)
                        item_y += 35

    pygame.display.flip()

pygame.quit()
