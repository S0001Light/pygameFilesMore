#!/usr/bin/env python3
from __future__ import annotations
import base64, ftplib, io, json, queue, socket, ssl, threading, tkinter as tk
from pathlib import Path, PurePosixPath
from tkinter import filedialog,messagebox,simpledialog,ttk
from PIL import Image,ImageTk
class App(tk.Tk):
 def __init__(self):
  super().__init__(); self.title('Secure FTPS + TLS Chat'); self.geometry('1050x680'); self.events=queue.Queue(); self.ftp=None; self.sock=None; self.writer=None; self.role='client'; self.remote=PurePosixPath('/'); self.icon_data=''; self.photos={}; self.build(); self.after(100,self.poll); self.protocol('WM_DELETE_WINDOW',self.close)
 def build(self):
  f=ttk.LabelFrame(self,text='Secure connection'); f.pack(fill='x',padx=10,pady=8)
  self.host=tk.StringVar(value='127.0.0.1'); self.fp=tk.StringVar(value='2121'); self.cp=tk.StringVar(value='5050'); self.user=tk.StringVar(); self.pw=tk.StringVar()
  for i,(n,v,w) in enumerate([('Host',self.host,16),('FTPS',self.fp,6),('Chat TLS',self.cp,6),('Username',self.user,14),('Password',self.pw,14)]):
   ttk.Label(f,text=n).grid(row=0,column=i*2,padx=3); ttk.Entry(f,textvariable=v,width=w,show='*' if n=='Password' else '').grid(row=0,column=i*2+1,padx=3)
  ttk.Button(f,text='My icon...',command=self.pick_icon).grid(row=1,column=8); ttk.Button(f,text='Connect',command=self.connect).grid(row=1,column=12,padx=5); self.disconnect_btn=ttk.Button(f,text='Disconnect',command=self.manual_disconnect,state='disabled'); self.disconnect_btn.grid(row=1,column=13,padx=5)
  self.tabs=ttk.Notebook(self); self.tabs.pack(fill='both',expand=True,padx=10,pady=5); self.files=ttk.Frame(self.tabs); self.chat=ttk.Frame(self.tabs); self.tabs.add(self.files,text='Files'); self.tabs.add(self.chat,text='Chat')
  bar=ttk.Frame(self.files); bar.pack(fill='x',pady=5); self.path=ttk.Label(bar,text='/'); self.path.pack(side='left',padx=8)
  for n,c in [('Up',self.up),('Refresh',self.refresh),('Upload',self.upload),('Download',self.download),('New folder (admin)',self.mkdir),('Delete (admin)',self.delete)]: ttk.Button(bar,text=n,command=c).pack(side='left',padx=2)
  self.tree=ttk.Treeview(self.files,columns=('type','size'),show='tree headings'); self.tree.heading('#0',text='Name'); self.tree.heading('type',text='Type'); self.tree.heading('size',text='Size'); self.tree.pack(fill='both',expand=True,padx=8,pady=5); self.tree.bind('<Double-1>',lambda e:self.open_folder())
  pan=ttk.Panedwindow(self.chat,orient='horizontal'); pan.pack(fill='both',expand=True,padx=8,pady=8); left=ttk.Frame(pan); right=ttk.Frame(pan); pan.add(left,weight=4); pan.add(right,weight=1)
  self.log=tk.Text(left,state='disabled',wrap='word'); self.log.pack(fill='both',expand=True); row=ttk.Frame(left); row.pack(fill='x',pady=5); self.msg=tk.StringVar(); e=ttk.Entry(row,textvariable=self.msg); e.pack(side='left',fill='x',expand=True); e.bind('<Return>',lambda x:self.send()); ttk.Button(row,text='Send',command=self.send).pack(side='left')
  ttk.Label(right,text='Online').pack(); self.roster=tk.Listbox(right); self.roster.pack(fill='both',expand=True); self.status=tk.StringVar(value='Disconnected'); ttk.Label(self,textvariable=self.status).pack(fill='x',padx=12,pady=5)
 def pick_icon(self):
  p=filedialog.askopenfilename(filetypes=[('Images','*.png *.jpg *.jpeg')]);
  if not p:return
  im=Image.open(p).convert('RGBA'); im.thumbnail((64,64)); b=io.BytesIO(); im.save(b,'PNG'); self.icon_data=base64.b64encode(b.getvalue()).decode(); self.status.set('Icon selected')
 def context(self):
  # Bundled/default server certificate. No file selector in the UI.
  cert=Path(__file__).with_name('server_cert.pem')
  if cert.exists():
   ctx=ssl.create_default_context(cafile=str(cert)); ctx.check_hostname=False; return ctx
  # Self-signed server cert is accepted automatically; the channel remains TLS encrypted.
  return ssl._create_unverified_context()
 def connect(self):
  vals=(self.host.get().strip(),int(self.fp.get()),int(self.cp.get()),self.user.get().strip(),self.pw.get(),self.icon_data)
  threading.Thread(target=self._connect,args=vals,daemon=True).start(); self.status.set('Connecting with TLS...')
 def _connect(self,h,fp,cp,u,pw,icon):
  try:
   self.disconnect(); ctx=self.context(); ftp=ftplib.FTP_TLS(context=ctx); ftp.connect(h,fp,timeout=10); ftp.auth(); ftp.login(u,pw); ftp.prot_p(); ftp.set_pasv(True)
   raw=socket.create_connection((h,cp),timeout=15); sock=ctx.wrap_socket(raw,server_hostname=h); sock.settimeout(None); sock.setsockopt(socket.SOL_SOCKET,socket.SO_KEEPALIVE,1); w=sock.makefile('w',encoding='utf-8',newline='\n'); w.write(json.dumps({'username':u,'password':pw,'icon':icon})+'\n'); w.flush(); self.ftp,self.sock,self.writer=ftp,sock,w; self.events.put(('connected',None)); threading.Thread(target=self.reader,args=(sock,),daemon=True).start()
  except Exception as e:self.disconnect(); self.events.put(('error',str(e)))
 def reader(self,s):
  try:
   for line in s.makefile('r',encoding='utf-8'):
    if not line: break
    try: msg=json.loads(line)
    except json.JSONDecodeError: continue
    self.events.put(('chat',msg))
    if msg.get('type')=='error': break
  except (OSError,ssl.SSLError) as e:self.events.put(('chat_status',f'Chat disconnected: {e}'))
 def poll(self):
  try:
   while True:
    k,d=self.events.get_nowait()
    if k=='connected':self.status.set('Encrypted FTPS + TLS chat connected'); self.disconnect_btn.config(state='normal'); self.remote=PurePosixPath('/'); self.refresh()
    elif k=='error':self.status.set('Disconnected'); self.disconnect_btn.config(state='disabled'); messagebox.showerror('Secure connection',d)
    elif k=='chat':self.show_chat(d)
    elif k=='chat_status':self.status.set(d)
  except queue.Empty:pass
  self.after(100,self.poll)
 def photo(self,data,key):
  if not data:return None
  try:
   raw=base64.b64decode(data,validate=True); im=Image.open(io.BytesIO(raw)).convert('RGBA'); im.thumbnail((32,32)); ph=ImageTk.PhotoImage(im); self.photos[key]=ph; return ph
  except Exception:return None
 def show_chat(self,m):
  if m.get('type')=='error':
   self.status.set('Chat login rejected'); messagebox.showerror('Chat',m.get('text','Chat login failed')); return
  if m.get('type')=='welcome': self.role=m.get('role','client'); self.status.set(f"Connected securely as {self.role}")
  if m.get('type')=='roster':
   self.roster.delete(0,'end')
   for x in m.get('users',[]): self.roster.insert('end','[icon] '+x['username'] if x.get('icon') else '👤 '+x['username'])
   return
  self.log.config(state='normal')
  if m.get('type')=='message':
   key=f"{m.get('username')}:{len(self.photos)}"; ph=self.photo(m.get('icon',''),key)
   if ph:self.log.image_create('end',image=ph);self.log.insert('end',' ')
   self.log.insert('end',f"{m.get('username')}: {m.get('text')}\n")
  else:self.log.insert('end',f"*** {m.get('text','')}\n")
  self.log.see('end'); self.log.config(state='disabled')
 def task(self,fn):
  if not self.ftp:return messagebox.showwarning('FTPS','Connect first')
  def run():
   try:fn()
   except Exception as e:self.events.put(('error',str(e)))
  threading.Thread(target=run,daemon=True).start()
 def refresh(self):
  def work():
   self.ftp.cwd(str(self.remote)); rows=[]
   for n,f in self.ftp.mlsd():
    if n not in ('.','..'):rows.append((n,f.get('type','file'),f.get('size','')))
   self.after(0,lambda:self.render(rows))
  self.task(work)
 def render(self,rows):
  self.tree.delete(*self.tree.get_children()); self.path.config(text=str(self.remote))
  for n,t,s in sorted(rows,key=lambda x:(x[1]!='dir',x[0].lower())):self.tree.insert('', 'end',text=n,values=('Folder' if t=='dir' else 'File',s if t!='dir' else ''))
 def sel(self):
  x=self.tree.selection();
  if not x:return None
  v=self.tree.item(x[0]); return v['text'],v['values'][0]
 def open_folder(self):
  x=self.sel()
  if x and x[1]=='Folder':self.remote/=x[0];self.refresh()
 def up(self):
  if self.remote!=PurePosixPath('/'):self.remote=self.remote.parent;self.refresh()
 def upload(self):
  p=filedialog.askopenfilename()
  if not p:return
  def work():
   self.ftp.cwd(str(self.remote)); f=open(p,'rb'); self.ftp.storbinary('STOR '+Path(p).name,f); f.close(); self.after(0,self.refresh)
  self.task(work)
 def download(self):
  x=self.sel()
  if not x or x[1]!='File':return
  p=filedialog.asksaveasfilename(initialfile=x[0])
  if p:self.task(lambda:(self.ftp.cwd(str(self.remote)),self.ftp.retrbinary('RETR '+x[0],open(p,'wb').write)))
 def mkdir(self):
  n=simpledialog.askstring('Admin folder','Folder name:')
  if n:self.task(lambda:(self.ftp.cwd(str(self.remote)),self.ftp.mkd(n),self.after(0,self.refresh)))
 def delete(self):
  x=self.sel()
  if x and messagebox.askyesno('Delete',x[0]):self.task(lambda:(self.ftp.cwd(str(self.remote)),self.ftp.rmd(x[0]) if x[1]=='Folder' else self.ftp.delete(x[0]),self.after(0,self.refresh)))
 def send(self):
  t=self.msg.get().strip()
  if t and self.writer:
   try:self.writer.write(json.dumps({'type':'message','text':t},ensure_ascii=False)+'\n');self.writer.flush();self.msg.set('')
   except (OSError,ValueError) as e:self.status.set(f'Chat send failed: {e}')
 def manual_disconnect(self):
  self.disconnect(); self.status.set('Disconnected'); self.disconnect_btn.config(state='disabled'); self.roster.delete(0,'end'); self.log.config(state='normal'); self.log.insert('end','*** Disconnected.\n'); self.log.see('end'); self.log.config(state='disabled')
 def disconnect(self):
  for x in (self.writer,self.sock,self.ftp):
   try:x.close() if x else None
   except:pass
  self.writer=self.sock=self.ftp=None
 def close(self):self.disconnect();self.destroy()
if __name__=='__main__':App().mainloop()
