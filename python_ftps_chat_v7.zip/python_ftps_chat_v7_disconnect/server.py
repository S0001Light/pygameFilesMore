#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, json, logging, socket, ssl, threading, ipaddress
from pathlib import Path
from datetime import datetime, timedelta, timezone
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from typing import TextIO
import bcrypt
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import TLS_FTPHandler
from pyftpdlib.servers import ThreadedFTPServer

MAX_LINE=512*1024


def ensure_certificate(cert_path: str, key_path: str) -> None:
    cert = Path(cert_path)
    key = Path(key_path)
    if cert.exists() and key.exists():
        print(f"Using existing TLS certificate: {cert}")
        return
    if cert.exists() != key.exists():
        raise RuntimeError("TLS certificate/key mismatch: remove the remaining PEM file so both can be regenerated together.")

    hostname = socket.gethostname() or "localhost"
    san = [x509.DNSName(hostname), x509.DNSName("localhost"), x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]
    try:
        for info in socket.getaddrinfo(hostname, None):
            addr = info[4][0]
            try:
                ip = ipaddress.ip_address(addr)
                entry = x509.IPAddress(ip)
                if entry not in san:
                    san.append(entry)
            except ValueError:
                pass
    except OSError:
        pass

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, hostname)])
    now = datetime.now(timezone.utc)
    certificate = (
        x509.CertificateBuilder()
        .subject_name(subject).issuer_name(issuer).public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5))
        .not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.SubjectAlternativeName(san), critical=False)
        .sign(private_key, hashes.SHA256())
    )
    key.write_bytes(private_key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    cert.write_bytes(certificate.public_bytes(serialization.Encoding.PEM))
    print(f"Generated TLS certificate automatically: {cert}")
    print(f"Keep this private key secret: {key}")

def load_users(path: Path):
    data=json.loads(path.read_text(encoding="utf-8"))
    out={}
    for u in data.get("users",[]):
        name=str(u["username"]).strip()
        if not name or name in out: raise ValueError("Invalid or duplicate username")
        if u.get("role") not in ("admin","client"): raise ValueError(f"Invalid role for {name}")
        out[name]=u
    if not any(u["role"]=="admin" and u.get("enabled",True) for u in out.values()):
        raise ValueError("At least one enabled admin is required")
    return out

def verify(user, password):
    try: return bcrypt.checkpw(password.encode(), user["password_hash"].encode())
    except Exception: return False

class AllowlistAuthorizer(DummyAuthorizer):
    def validate_authentication(self, username, password, handler):
        import bcrypt
        if username not in self.user_table: self._raise_perm(username)
        stored=self.user_table[username]["pwd"]
        if not bcrypt.checkpw(password.encode(), stored.encode()): self._raise_perm(username)
    @staticmethod
    def _raise_perm(username):
        from pyftpdlib.authorizers import AuthenticationFailed
        raise AuthenticationFailed(f"Authentication failed for {username}")

class ChatServer:
    def __init__(self,host,port,users,context):
        self.host,self.port,self.users,self.context=host,port,users,context
        self.lock=threading.RLock(); self.clients={}
    def start(self):
        listener=socket.socket(); listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        listener.bind((self.host,self.port)); listener.listen(50)
        print(f"TLS chat listening on {self.host}:{self.port}")
        while True:
            raw,addr=listener.accept()
            try:
                raw.settimeout(15)
                sock=self.context.wrap_socket(raw,server_side=True)
                sock.settimeout(None)
                sock.setsockopt(socket.SOL_SOCKET,socket.SO_KEEPALIVE,1)
            except (ssl.SSLError,TimeoutError,OSError): raw.close(); continue
            threading.Thread(target=self.handle,args=(sock,addr),daemon=True).start()
    @staticmethod
    def send(w,p): w.write(json.dumps(p,ensure_ascii=False)+"\n"); w.flush()
    def broadcast(self,p):
        dead=[]
        with self.lock:
            for s,(name,w,icon) in list(self.clients.items()):
                try: self.send(w,p)
                except Exception: dead.append(s)
            for s in dead: self.drop(s)
    def roster(self):
        return [{"username":n,"icon":i} for n,w,i in self.clients.values()]
    def drop(self,s):
        item=self.clients.pop(s,None)
        try:s.close()
        except:pass
        return item[0] if item else None
    def handle(self,sock,addr):
        writer=None; name=None
        try:
            reader=sock.makefile("r",encoding="utf-8",newline="\n"); writer=sock.makefile("w",encoding="utf-8",newline="\n")
            hello=json.loads(reader.readline(MAX_LINE)); name=str(hello.get("username","")).strip()
            user=self.users.get(name)
            if not user or not user.get("enabled",True) or not verify(user,str(hello.get("password",""))):
                self.send(writer,{"type":"error","text":"Not on the allowlist or invalid password."}); return
            icon=str(hello.get("icon", ""))
            if len(icon)>350000: icon=""
            with self.lock:
                if any(n.casefold()==name.casefold() for n,w,i in self.clients.values()):
                    self.send(writer,{"type":"error","text":"That name is already connected."}); return
                self.clients[sock]=(name,writer,icon)
            self.send(writer,{"type":"welcome","text":f"Connected as {name}.","role":user["role"]})
            self.broadcast({"type":"roster","users":self.roster()})
            self.broadcast({"type":"system","text":f"{name} joined."})
            for line in reader:
                msg=json.loads(line)
                if msg.get("type")=="message":
                    text=str(msg.get("text","")).strip()[:2000]
                    if text:self.broadcast({"type":"message","username":name,"text":text,"icon":icon})
        except Exception as e: logging.debug("chat ended: %s",e)
        finally:
            with self.lock: left=self.drop(sock)
            if left:
                self.broadcast({"type":"system","text":f"{left} left."}); self.broadcast({"type":"roster","users":self.roster()})

def build_ftp(args,users):
    root=Path(args.root).resolve(); uploads=root/'uploads'; root.mkdir(parents=True,exist_ok=True); uploads.mkdir(exist_ok=True)
    auth=AllowlistAuthorizer()
    for name,u in users.items():
        if not u.get("enabled",True): continue
        perms="elradfmwMT" if u["role"]=="admin" else "elr"
        auth.add_user(name,u["password_hash"],str(root),perm=perms)
        if u["role"]=="client": auth.override_perm(name,str(uploads),perm="elrw",recursive=False)
    class Handler(TLS_FTPHandler): pass
    Handler.authorizer=auth; Handler.certfile=args.cert; Handler.keyfile=args.key
    Handler.tls_control_required=True; Handler.tls_data_required=True
    Handler.passive_ports=range(args.passive_start,args.passive_end+1)
    Handler.banner="FTPS-only secure file server"
    return ThreadedFTPServer((args.host,args.ftps_port),Handler)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--host',default='0.0.0.0'); p.add_argument('--ftps-port',type=int,default=2121)
    p.add_argument('--chat-port',type=int,default=5050); p.add_argument('--root',default='shared_files'); p.add_argument('--users',default='users.json')
    p.add_argument('--cert',default='server_cert.pem'); p.add_argument('--key',default='server_key.pem'); p.add_argument('--passive-start',type=int,default=50000); p.add_argument('--passive-end',type=int,default=50049)
    a=p.parse_args(); users=load_users(Path(a.users))
    ensure_certificate(a.cert, a.key)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.minimum_version=ssl.TLSVersion.TLSv1_2; ctx.load_cert_chain(a.cert,a.key)
    ftp=build_ftp(a,users); threading.Thread(target=ChatServer(a.host,a.chat_port,users,ctx).start,daemon=True).start()
    print(f"FTPS-only server on {a.host}:{a.ftps_port}; allowed clients loaded from {a.users}")
    try: ftp.serve_forever()
    except KeyboardInterrupt: pass
    finally: ftp.close_all()
if __name__=='__main__': main()
