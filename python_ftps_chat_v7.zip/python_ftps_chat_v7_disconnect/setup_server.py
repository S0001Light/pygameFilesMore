#!/usr/bin/env python3
import argparse,json
from pathlib import Path
import bcrypt
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from datetime import datetime,timedelta,timezone
p=argparse.ArgumentParser();p.add_argument('--hostname',default='localhost');p.add_argument('--admin',default='admin');p.add_argument('--password',required=True);a=p.parse_args()
key=rsa.generate_private_key(public_exponent=65537,key_size=3072); name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,a.hostname)])
cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=5)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=365)).add_extension(x509.SubjectAlternativeName([x509.DNSName(a.hostname),x509.DNSName('localhost')]),False).sign(key,hashes.SHA256()))
Path('server_key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()));Path('server_cert.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
h=bcrypt.hashpw(a.password.encode(),bcrypt.gensalt()).decode();Path('users.json').write_text(json.dumps({'users':[{'username':a.admin,'password_hash':h,'role':'admin','enabled':True}]},indent=2));print('Created certificate, private key, and users.json')
