# Secure FTPS + TLS Chat v2

This version enforces explicit FTPS on both control and data channels, protects chat with TLS, uses a JSON client allowlist with bcrypt password hashes, supports admin and client roles, and lets each chat user choose a PNG/JPEG icon.

## Install and initialize

```bat
py -m pip install -r requirements.txt
py setup_server.py --hostname localhost --admin admin --password "Choose-A-Strong-Password"
```

`server.py` now automatically creates `server_cert.pem` and `server_key.pem` on first launch if both are missing. `setup_server.py` is still used to create the first admin account / `users.json`.

For LAN use, replace `localhost` with the server DNS name clients will enter. Copy `server_cert.pem` to each approved client through a trusted method. Never distribute `server_key.pem`.

## Add an allowed client

```bat
py manage_user.py shawn --password "Client-Password" --role client
```

Add another admin with `--role admin`. Remove or disable a user by editing `users.json` and setting `enabled` to false. Restart the server after allowance changes.

## Run

```bat
py server.py
py client.py
```

Client accounts can browse and download throughout the shared root, but can upload only while located directly in `/uploads`. They cannot create folders, rename, or delete. Admin accounts have full file permissions including folder creation. The server enforces these rules, not just the client UI.

## TLS notes

The server automatically generates a self-signed certificate on first launch if one is missing. The automatically generated certificate is valid for ten years. The client verifies the server against the selected certificate and checks its hostname. Use the exact hostname placed in the certificate. For public deployment, use a certificate issued by a trusted CA.

Open TCP 2121, 5050, and passive ports 50000-50049 on the server firewall. Do not expose the private key.


## Client certificate UI

The Trusted certificate field and Certificate button have been removed. If `server_cert.pem` is beside `client.py`, the client automatically uses it for verification. If it is absent, the client still uses TLS but cannot authenticate the self-signed server identity.


## Chat timeout fix

Connection and TLS handshakes use a 15-second timeout. After the secure chat connection is established, both client and server switch the socket back to blocking mode with no idle read timeout and enable TCP keepalive. This prevents the original connection timeout from terminating an otherwise idle chat.
