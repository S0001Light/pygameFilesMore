#!/usr/bin/env python3
import argparse,bcrypt,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('username');p.add_argument('--password',required=True);p.add_argument('--role',choices=['client','admin'],default='client');p.add_argument('--disable',action='store_true');p.add_argument('--file',default='users.json');a=p.parse_args();path=Path(a.file);d=json.loads(path.read_text());d['users']=[u for u in d['users'] if u['username']!=a.username];d['users'].append({'username':a.username,'password_hash':bcrypt.hashpw(a.password.encode(),bcrypt.gensalt()).decode(),'role':a.role,'enabled':not a.disable});path.write_text(json.dumps(d,indent=2));print('Updated allowlist:',a.username)
