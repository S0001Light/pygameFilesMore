@echo off
setlocal
set "PINFILE=%USERPROFILE%\.secure_chat_pins.json"

echo Secure Chat certificate-pin reset
echo.
if not exist "%PINFILE%" (
  echo No saved certificate pin was found.
  echo File checked: %PINFILE%
  pause
  exit /b 0
)

copy /y "%PINFILE%" "%PINFILE%.backup" >nul
if errorlevel 1 (
  echo ERROR: Could not back up the pin file.
  pause
  exit /b 1
)

del /f /q "%PINFILE%"
if exist "%PINFILE%" (
  echo ERROR: Could not remove the saved certificate pin.
  pause
  exit /b 1
)

echo SUCCESS: The old Secure Chat certificate pin was removed.
echo Backup: %PINFILE%.backup
echo.
echo Restart the trusted server, then reconnect the client.
echo The client will save the server's current certificate fingerprint.
pause
