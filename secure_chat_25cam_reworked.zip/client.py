#!/usr/bin/env python3
from __future__ import annotations
import base64,hashlib,io,json,queue,socket,ssl,threading,time,tkinter as tk
from pathlib import Path
from tkinter import filedialog,messagebox,ttk
from PIL import Image
from chat_icons import IconChatView,IconRoster
from video_grid import VideoGrid
from video_stream import MutedVideoClient
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('Secure Chat - 25 Camera Grid');self.geometry('1500x900');self.minsize(1100,700);self.events=queue.Queue();self.sock=None;self.writer=None;self.connected=False;self.icon_data='';self.last_pong=time.monotonic();self.build();self.video=MutedVideoClient(self);self.after(100,self.poll);self.after(25000,self.heartbeat);self.protocol('WM_DELETE_WINDOW',self.close)
 def build(self):
  top=ttk.LabelFrame(self,text='Secure connection');top.pack(fill='x',padx=10,pady=8);self.host=tk.StringVar(value='127.0.0.1');self.port=tk.StringVar(value='5050');self.user=tk.StringVar();self.password=tk.StringVar()
  for i,(name,var,width) in enumerate([('Host',self.host,18),('Port',self.port,7),('Username',self.user,16),('Password',self.password,16)]):ttk.Label(top,text=name).grid(row=0,column=i*2,padx=3,pady=7);ttk.Entry(top,textvariable=var,width=width,show='*' if name=='Password' else '').grid(row=0,column=i*2+1,padx=3,pady=7)
  ttk.Button(top,text='My icon...',command=self.pick_icon).grid(row=1,column=4,pady=5);ttk.Button(top,text='Connect',command=self.connect).grid(row=1,column=6);self.disconnect_button=ttk.Button(top,text='Disconnect',command=self.manual_disconnect,state='disabled');self.disconnect_button.grid(row=1,column=7,padx=5);self.camera_button=ttk.Button(top,text='Camera: OFF',command=self.toggle_camera);self.camera_button.grid(row=1,column=8,padx=5)
  split=ttk.Panedwindow(self,orient='horizontal');split.pack(fill='both',expand=True,padx=10,pady=5)
  chat_panel=ttk.Frame(split,width=330);cams_panel=ttk.Frame(split);split.add(chat_panel,weight=2);split.add(cams_panel,weight=5)
  self.chat_view=IconChatView(chat_panel,lambda:self.user.get());self.chat_view.pack(fill='both',expand=True)
  compose=ttk.Frame(chat_panel);compose.pack(fill='x',pady=6);self.message=tk.StringVar();entry=ttk.Entry(compose,textvariable=self.message);entry.pack(side='left',fill='x',expand=True);entry.bind('<Return>',lambda e:self.send());ttk.Button(compose,text='Send',command=self.send).pack(side='left',padx=(6,0))
  ttk.Label(chat_panel,text='Online users',font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(4,2));self.roster=IconRoster(chat_panel);self.roster.pack(fill='x')
  self.video_grid=VideoGrid(cams_panel);self.video_grid.pack(fill='both',expand=True)
  self.status=tk.StringVar(value='Disconnected');ttk.Label(self,textvariable=self.status,anchor='w').pack(fill='x',padx=12,pady=(0,8))

 def toggle_camera(self):
  self.video.toggle_camera()
 def update_camera_button(self):
  if not hasattr(self,'camera_button'):return
  self.camera_button.config(text='Camera: ON' if self.video.camera_enabled else 'Camera: OFF')
 def context(self):ctx=ssl._create_unverified_context();ctx.minimum_version=ssl.TLSVersion.TLSv1_2;return ctx
 def pin(self,sock):
  fingerprint=hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest();path=Path.home()/'.secure_chat_pins.json';pins={}
  try:pins=json.loads(path.read_text())
  except Exception:pass
  key=f'{self.host.get()}:{self.port.get()}'
  if key in pins and pins[key]!=fingerprint:raise ssl.SSLError('The server certificate changed. Connection blocked.')
  if key not in pins:pins[key]=fingerprint;path.write_text(json.dumps(pins,indent=2))
 def pick_icon(self):
  p=filedialog.askopenfilename(filetypes=[('Images','*.png *.jpg *.jpeg')])
  if not p:return
  im=Image.open(p).convert('RGBA');im.thumbnail((64,64));b=io.BytesIO();im.save(b,'PNG');self.icon_data=base64.b64encode(b.getvalue()).decode();self.status.set('Icon selected')
 def connect(self):
  if self.connected:return
  self.status.set('Connecting securely...');threading.Thread(target=self._connect,daemon=True).start()
 def _connect(self):
  try:
   raw=socket.create_connection((self.host.get().strip(),int(self.port.get())),timeout=15);sock=self.context().wrap_socket(raw,server_hostname=self.host.get().strip());self.pin(sock);sock.settimeout(None);sock.setsockopt(socket.SOL_SOCKET,socket.SO_KEEPALIVE,1)
   if hasattr(socket,'SIO_KEEPALIVE_VALS'):sock.ioctl(socket.SIO_KEEPALIVE_VALS,(1,30000,10000))
   writer=sock.makefile('w',encoding='utf-8',newline='\n');writer.write(json.dumps({'username':self.user.get().strip(),'password':self.password.get(),'icon':self.icon_data})+'\n');writer.flush();self.sock,self.writer=sock,writer;self.connected=True;self.last_pong=time.monotonic();self.events.put(('connected',None));threading.Thread(target=self.reader,args=(sock,),daemon=True).start()
  except Exception as exc:self.disconnect();self.events.put(('error',str(exc)))
 def reader(self,sock):
  try:
   for line in sock.makefile('r',encoding='utf-8',newline='\n'):
    try:msg=json.loads(line)
    except json.JSONDecodeError:continue
    if msg.get('type')=='pong':self.last_pong=time.monotonic();continue
    self.events.put(('chat',msg))
  except Exception as exc:
   if self.connected:self.events.put(('error','Chat disconnected: '+str(exc)))
  finally:
   if self.connected:self.disconnect();self.events.put(('closed',None))
 def heartbeat(self):
  if self.connected and self.writer:
   try:
    self.writer.write('{"type":"ping"}\n');self.writer.flush()
    if time.monotonic()-self.last_pong>75:raise TimeoutError('Server heartbeat lost')
   except Exception as exc:self.events.put(('error','Heartbeat failed: '+str(exc)));self.disconnect()
  self.after(25000,self.heartbeat)
 def poll(self):
  try:
   while True:
    kind,data=self.events.get_nowait()
    if kind=='connected':self.status.set('Securely connected - video muted');self.disconnect_button.config(state='normal');self.video.start()
    elif kind=='video_error':self.status.set(data);messagebox.showerror('Secure Chat Video',data)
    elif kind=='video_status':self.status.set(data)
    elif kind=='error':self.status.set('Disconnected');self.disconnect_button.config(state='disabled');messagebox.showerror('Secure chat',data)
    elif kind=='closed':self.status.set('Disconnected');self.disconnect_button.config(state='disabled');self.roster.set_users([])
    else:self.show_chat(data)
  except queue.Empty:pass
  self.after(100,self.poll)
 def show_chat(self,msg):
  kind=msg.get('type')
  if kind=='error':messagebox.showerror('Chat login',msg.get('text','Login failed'));self.disconnect();return
  if kind=='roster':self.roster.set_users(msg.get('users',[]));return
  if kind=='message':self.chat_view.message(msg.get('username','?'),msg.get('text',''),msg.get('icon',''),msg.get('role','client'));return
  self.chat_view.system(msg.get('text',''))
 def send(self):
  text=self.message.get().strip()
  if not text or not self.writer:return
  try:self.writer.write(json.dumps({'type':'message','text':text},ensure_ascii=False)+'\n');self.writer.flush();self.message.set('')
  except Exception as exc:self.status.set('Send failed: '+str(exc))
 def manual_disconnect(self):self.video.stop();self.disconnect();self.status.set('Disconnected');self.disconnect_button.config(state='disabled');self.roster.set_users([]);self.chat_view.system('Disconnected.')
 def disconnect(self):
  self.connected=False
  for obj in (self.writer,self.sock):
   try:obj.close() if obj else None
   except Exception:pass
  self.writer=self.sock=None
 def close(self):self.video.stop();self.disconnect();self.destroy()
if __name__=='__main__':App().mainloop()
