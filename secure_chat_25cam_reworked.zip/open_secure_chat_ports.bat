@echo off
setlocal

:: Request Administrator rights if needed
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Requesting Administrator permission...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

echo Opening Secure Chat TCP ports 5050 and 5051...

netsh advfirewall firewall delete rule name="Secure Chat TCP 5050" >nul 2>&1
netsh advfirewall firewall delete rule name="Secure Chat Video TCP 5051" >nul 2>&1

netsh advfirewall firewall add rule name="Secure Chat TCP 5050" dir=in action=allow protocol=TCP localport=5050 profile=any enable=yes
if errorlevel 1 goto :failed

netsh advfirewall firewall add rule name="Secure Chat Video TCP 5051" dir=in action=allow protocol=TCP localport=5051 profile=any enable=yes
if errorlevel 1 goto :failed

echo.
echo SUCCESS: TCP ports 5050 and 5051 are allowed inbound.
echo Start the server with: py server.py
echo.
pause
exit /b 0

:failed
echo.
echo ERROR: Windows Firewall rule creation failed.
echo Make sure Windows Defender Firewall is available and try again as Administrator.
echo.
pause
exit /b 1
