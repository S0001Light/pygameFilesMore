from __future__ import annotations
import json, socket, struct, threading, time, sys
import cv2, numpy as np
from PIL import Image

VIDEO_PORT = 5051
MAX_PACKET = 600000

class MutedVideoClient:
    def __init__(self, app):
        self.app=app; self.sock=None; self.running=False; self.cap=None
        self.slots={}; self.camera_enabled=False; self.sender_thread=None; self.receiver_thread=None
        self.camera_index=None; self.send_lock=threading.Lock()

    @staticmethod
    def recv_exact(sock,n):
        b=bytearray()
        while len(b)<n:
            c=sock.recv(n-len(b))
            if not c: raise ConnectionError('video socket closed')
            b.extend(c)
        return bytes(b)

    def start(self):
        if self.running:return
        host=self.app.host.get().strip()
        try:
            raw=socket.create_connection((host,VIDEO_PORT),timeout=15)
            sock=self.app.context().wrap_socket(raw,server_hostname=host)
            self.app.pin(sock)
            sock.settimeout(None)
            hello=json.dumps({'username':self.app.user.get().strip(),'password':self.app.password.get()}).encode('utf-8')
            sock.sendall(struct.pack('!I',len(hello))+hello)
            self.sock=sock; self.running=True
            self.app.events.put(('video_status',f'Video relay connected on {host}:{VIDEO_PORT}'))
            self.receiver_thread=threading.Thread(target=self.recv_loop,daemon=True); self.receiver_thread.start()
            if self.camera_enabled:self._open_camera()
        except Exception as e:
            self.running=False
            self.app.events.put(('video_error',f'Video relay {host}:{VIDEO_PORT}: {e}'))

    def _camera_candidates(self):
        backends=[]
        if sys.platform.startswith('win'):
            backends=[cv2.CAP_DSHOW,cv2.CAP_MSMF,cv2.CAP_ANY]
        else: backends=[cv2.CAP_ANY]
        for index in range(5):
            for backend in backends: yield index,backend

    def _open_camera(self):
        if not self.running:
            self.app.events.put(('video_error','Video relay is not connected.'))
            return
        if self.cap is not None:return
        for index,backend in self._camera_candidates():
            cap=cv2.VideoCapture(index,backend)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH,320); cap.set(cv2.CAP_PROP_FRAME_HEIGHT,240)
                cap.set(cv2.CAP_PROP_BUFFERSIZE,1)
                ok,frame=cap.read()
                if ok and frame is not None and frame.size:
                    self.cap=cap; self.camera_index=index; self.camera_enabled=True
                    self.app.events.put(('video_status',f'Camera {index} opened; local preview active'))
                    self.app.after(0,self.app.update_camera_button)
                    self.sender_thread=threading.Thread(target=self.send_loop,daemon=True);self.sender_thread.start()
                    return
            cap.release()
        self.camera_enabled=False
        self.app.after(0,self.app.update_camera_button)
        self.app.events.put(('video_error','No usable webcam found. Close other camera apps and allow desktop camera access in Windows Settings.'))

    def set_camera(self,enabled):
        if enabled:
            self.camera_enabled=True; self._open_camera()
        else:
            self.camera_enabled=False
            cap,self.cap=self.cap,None
            if cap:
                try:cap.release()
                except Exception:pass
            self.app.after(0,self.app.update_camera_button)

    def toggle_camera(self):self.set_camera(not self.camera_enabled)

    def send_loop(self):
        failures=0
        while self.running and self.camera_enabled and self.cap and self.cap.isOpened():
            ok,frame=self.cap.read()
            if not ok or frame is None:
                failures+=1
                if failures>=20:
                    self.app.events.put(('video_error','Camera stopped producing frames.'))
                    break
                time.sleep(.1);continue
            failures=0
            frame=cv2.resize(frame,(320,240))
            # Show our own camera immediately in slot 1.
            rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            preview=Image.fromarray(rgb)
            self.app.after(0,self.app.video_grid.tiles[0].set_frame,preview,self.app.user.get().strip()+' [you, muted]')
            ok,buf=cv2.imencode('.jpg',frame,[cv2.IMWRITE_JPEG_QUALITY,60])
            if ok:
                data=buf.tobytes()
                try:
                    with self.send_lock:self.sock.sendall(struct.pack('!I',len(data))+data)
                except Exception as exc:
                    self.app.events.put(('video_error','Video send failed: '+str(exc)));break
            time.sleep(.10)
        self.set_camera(False)

    def recv_loop(self):
        try:
            while self.running:
                n=struct.unpack('!I',self.recv_exact(self.sock,4))[0]
                if n<=0 or n>MAX_PACKET:raise ValueError('invalid incoming video packet')
                packet=self.recv_exact(self.sock,n)
                meta,frame=packet.split(b'\n',1)
                name=json.loads(meta.decode('utf-8'))['username']
                arr=np.frombuffer(frame,np.uint8);img=cv2.imdecode(arr,cv2.IMREAD_COLOR)
                if img is not None:self.app.after(0,self.show,name,img)
        except Exception as exc:
            if self.running:self.app.events.put(('video_error','Video receive stopped: '+str(exc)))
        self.stop()

    def show(self,name,bgr):
        if name not in self.slots:
            used=set(self.slots.values())
            # Reserve slot zero for local preview.
            self.slots[name]=next((i for i in range(1,25) if i not in used),None)
        i=self.slots.get(name)
        if i is None:return
        rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
        self.app.video_grid.tiles[i].set_frame(Image.fromarray(rgb),name+' [muted]')

    def stop(self):
        self.running=False;self.camera_enabled=False
        cap,self.cap=self.cap,None
        if cap:
            try:cap.release()
            except Exception:pass
        sock,self.sock=self.sock,None
        if sock:
            try:sock.shutdown(socket.SHUT_RDWR)
            except Exception:pass
            try:sock.close()
            except Exception:pass
        self.app.after(0,self.app.update_camera_button)
